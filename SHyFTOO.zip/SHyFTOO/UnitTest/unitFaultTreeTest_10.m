
%% Define the Fault Tree Structure %%
Tm = 500; %[h]

%% Define BEs %%

BE1 = BasicEvent('BE1','exp','exp',[0.01],[0.05]);
BE2 = BasicEvent('BE2','exp','exp',[0.01],[0.05]);
BE3 = BasicEvent('BE3','exp','exp',[0.008],[0.05]);
BE4 = BasicEvent('BE4','exp','exp',[0.005],[0.05]);
BE5 = BasicEvent('BE5','exp','exp',[0.006],[0.05]);
BE6 = BasicEvent('BE6','exp','exp',[0.007],[0.05]);
BE7 = BasicEvent('BE7','exp','exp',[0.01],[0.05]);
BE8 = BasicEvent('BE8','exp','exp',[0.01],[0.05]);
BE9 = BasicEvent('BE9','exp','exp',[0.009],[0.05]);
BE10 = BasicEvent('BE10','exp','exp',[0.008],[0.05]);

% %% Define Gates %%
SEQ1 = Gate ('SEQ1', 'SEQ', false, [BE3, BE4, BE5]);
SEQ2 = Gate ('SEQ2', 'SEQ', false, [BE7, BE8, BE9]);
OR2 = Gate ('OR2', 'OR', false, [BE6, SEQ2]);
SPARE2 = Gate ('SPARE2', 'SPARE', false, [SEQ2], [SEQ1]);
SPARE1 = Gate ('SPARE1', 'SPARE', false, [BE1, BE2], [SEQ1]);
OR1 = Gate ('OR1', 'OR', false, [SPARE2, BE10]);
PAND1 = Gate ('PAND1', 'PAND', false, [SPARE1, OR2]);
AND1 = Gate ('AND1', 'AND', false, [PAND1, OR1]);
TOP = AND1;
%% Recall Matlab Script %%
%verify if the FT Structure is valid (it will modify the value of the variable UNVALID_FT)
createFTStructure

