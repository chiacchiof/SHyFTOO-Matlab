
%% Define the Fault Tree Structure %%
Tm = 500; %[h]

%% Define BEs %%

BE1 = BasicEvent('BE1','exp','exp',[0.008],[0.05]);
BE2 = BasicEvent('BE2','exp','exp',[0.005],[0.05]);
BE3 = BasicEvent('BE3','exp','exp',[0.006],[0.05]);
BE4 = BasicEvent('BE4','exp','exp',[0.007],[0.05]);

% %% Define Gates %%
OR1 = Gate ('OR1', 'OR', false, [BE3, BE4]);
SEQ1 = Gate ('SEQ1', 'SEQ', false, [BE1, BE2, OR1]);
TOP = SEQ1;
%% Recall Matlab Script %%
%verify if the FT Structure is valid (it will modify the value of the variable UNVALID_FT)
createFTStructure

