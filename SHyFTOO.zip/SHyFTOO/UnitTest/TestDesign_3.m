function [] = TestDesign()
    BEs = evalin('base', 'BEs');
    GATEs = evalin('base', 'GATEs');
    
    phase = evalin('base', 'phase');
    switch phase
    %% this section must be updated to implement the test
        case 0
            myArsset('BE2','FailureTime',10)
        case 1
            myArsset('BE3','FailureTime',15)
        case 2
            myArsset('BE2','RepairTime',20)
        otherwise
            nextEventTime = Inf;
            nextEvents = [];
            nextEvent = Inf;
            currentTime = Inf;
    end