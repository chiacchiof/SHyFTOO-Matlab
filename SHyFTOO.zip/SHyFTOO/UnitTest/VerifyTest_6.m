function [] = VerifyTest()
    phase = evalin('base', 'phase');
    FT = evalin('base','FT');
    nextEvents = evalin('base', 'nextEvents');
    nextEventTimeTest = evalin('base', 'nextEventTimeTest');
    switch (phase-1)
            case 0
                myAssert('OR1','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('SPARE1','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('BE2','Status', 'Constants.BAD', nextEventTimeTest);
                myAssert('BE5','InUseBy', 'SPARE1.Index', nextEventTimeTest);
                myAssert('AND1','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('PAND1','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('BE2','RepairTime', 'Inf', nextEventTimeTest);
            case 1
                myAssert('SPARE1','Status', 'Constants.BAD', nextEventTimeTest);
                myAssert('AND1','Status', 'Constants.BAD', nextEventTimeTest);
                myAssert('OR1','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('SEQ1','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('PAND1','Status', 'Constants.GOOD', nextEventTimeTest);
            case 2
                myAssert('SPARE1','Status', 'Constants.BAD', nextEventTimeTest);
                myAssert('AND1','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('OR1','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('SEQ1','InUseBy', 'Constants.MINUSONE', nextEventTimeTest);
                myAssert('PAND1','Status', 'Constants.GOOD', nextEventTimeTest);
            case 3
                myAssert('SPARE1','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('SEQ1','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('OR1','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('AND1','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('PAND1','Status', 'Constants.GOOD', nextEventTimeTest);
            case 4
                myAssert('SPARE1','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('SEQ1','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('AND1','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('OR1','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssertLess('BE4','FailureTime', 'Inf', nextEventTimeTest);
                myAssert('PAND1','Status', 'Constants.GOOD', nextEventTimeTest);
            case 5
                myAssert('OR1','Status', 'Constants.BAD', nextEventTimeTest);
                myAssert('SPARE1','Status', 'Constants.BAD', nextEventTimeTest);
                myAssert('SEQ1','Status', 'Constants.BAD', nextEventTimeTest);
                myAssert('AND1','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('PAND1','Status', 'Constants.GOOD', nextEventTimeTest);
            case 6
                myAssert('OR1','Status', 'Constants.BAD', nextEventTimeTest);
                myAssert('SPARE1','Status', 'Constants.BAD', nextEventTimeTest);
                myAssert('SEQ1','Status', 'Constants.BAD', nextEventTimeTest);
                myAssert('AND1','Status', 'Constants.BAD', nextEventTimeTest);
                myAssert('BE2','Status', 'Constants.BAD', nextEventTimeTest);
                myAssert('PAND1','Status', 'Constants.GOOD', nextEventTimeTest);
            case 7
                myAssert('OR1','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('BE4','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('SEQ1','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('AND1','Status', 'Constants.BAD', nextEventTimeTest);
                myAssert('PAND1','Status', 'Constants.GOOD', nextEventTimeTest);
            case 8
                myAssert('OR1','Status', 'Constants.BAD', nextEventTimeTest);
                myAssert('SEQ1','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('PAND1','Status', 'Constants.BAD', nextEventTimeTest);
            case 9
                myAssert('OR1','Status', 'Constants.BAD', nextEventTimeTest);
                myAssert('SPARE1','Status', 'Constants.BAD', nextEventTimeTest);
                myAssert('AND1','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('PAND1','Status', 'Constants.GOOD', nextEventTimeTest);
            case 10
                myAssert('OR1','Status', 'Constants.BAD', nextEventTimeTest);
                myAssert('SPARE1','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('BE5','InUseBy', 'SPARE1.Index', nextEventTimeTest);
                myAssert('AND1','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('PAND1','Status', 'Constants.GOOD', nextEventTimeTest);
            case 11
                myAssert('OR1','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('SPARE1','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('AND1','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('PAND1','Status', 'Constants.GOOD', nextEventTimeTest);
            case 12
                myAssert('OR1','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('SPARE1','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('AND1','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('BE2','Status', 'Constants.BAD', nextEventTimeTest);
                myAssert('PAND1','Status', 'Constants.GOOD', nextEventTimeTest);
            case 13
                myAssert('OR1','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('SPARE1','Status', 'Constants.BAD', nextEventTimeTest);
                myAssert('AND1','Status', 'Constants.BAD', nextEventTimeTest);
                myAssert('SEQ1','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('PAND1','Status', 'Constants.GOOD', nextEventTimeTest);
            case 14
                myAssert('OR1','Status', 'Constants.BAD', nextEventTimeTest);
                myAssert('SPARE1','Status', 'Constants.BAD', nextEventTimeTest);
                myAssert('AND1','Status', 'Constants.BAD', nextEventTimeTest);
                myAssert('SEQ1','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('PAND1','Status', 'Constants.BAD', nextEventTimeTest);
    end
end