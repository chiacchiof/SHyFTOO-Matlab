function [] = VerifyTest()
    phase = evalin('base', 'phase');
    FT = evalin('base','FT');
    nextEvents = evalin('base', 'nextEvents');
    nextEventTimeTest = evalin('base', 'nextEventTimeTest');
    switch (phase-1)
            case 0
                myAssert('SPARE1','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('SEQ1','InUseBy', 'SPARE1.Index', nextEventTimeTest);
                myAssert('SEQ2','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssertLess('BE8','FailureTime', 'Inf', nextEventTimeTest);
                myAssert('BE9','FailureTime', 'Inf', nextEventTimeTest);
            case 1
                myAssert('SPARE1','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('SEQ1','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('SEQ1','InUseBy', 'SPARE1.Index', nextEventTimeTest);
                myAssert('SEQ2','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('AND1','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssertLess('BE9','FailureTime', 'Inf', nextEventTimeTest);
                myAssertLess('BE4','FailureTime', 'Inf', nextEventTimeTest);
                myAssert('BE5','FailureTime', 'Inf', nextEventTimeTest);
            case 2
                myAssert('SPARE1','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('SEQ1','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('SEQ1','InUseBy', 'SPARE2.Index', nextEventTimeTest);
                myAssert('SEQ2','Status', 'Constants.BAD', nextEventTimeTest);
                myAssert('OR2','Status', 'Constants.BAD', nextEventTimeTest);
            case 3
                myAssert('OR2','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('SEQ2','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('SEQ1','InUseBy', 'Constants.MINUSONE', nextEventTimeTest);
                myAssert('OR1','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('SPARE2','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('BE8','FailureTime', 'Inf', nextEventTimeTest);
                myAssert('BE9','FailureTime', 'Inf', nextEventTimeTest);
            case 4
                myAssert('SPARE1','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('SEQ1','InUseBy', 'Constants.MINUSONE', nextEventTimeTest);
                myAssert('SPARE2','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('OR1','Status', 'Constants.BAD', nextEventTimeTest);
                myAssert('AND1','Status', 'Constants.GOOD', nextEventTimeTest);
            case 5
                myAssert('SPARE1','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('SEQ1','InUseBy', 'SPARE1.Index', nextEventTimeTest);
                myAssertLess('BE5','FailureTime', 'Inf', nextEventTimeTest);
                myAssert('PAND1','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('AND1','Status', 'Constants.GOOD', nextEventTimeTest);
            case 6
                myAssert('SPARE1','Status', 'Constants.BAD', nextEventTimeTest);
                myAssert('OR2','Status', 'Constants.BAD', nextEventTimeTest);
                myAssert('PAND1','Status', 'Constants.BAD', nextEventTimeTest);
                myAssert('SPARE2','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('AND1','Status', 'Constants.BAD', nextEventTimeTest);
    end
end