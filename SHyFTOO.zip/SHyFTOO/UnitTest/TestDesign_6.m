function [] = TestDesign()
    BEs = evalin('base', 'BEs');
    GATEs = evalin('base', 'GATEs');
    
    phase = evalin('base', 'phase');
    switch phase
    %% this section must be updated to implement the test
        case 0
            myArsset('BE1','FailureTime',10)
        case 1
            myArsset('BE5','FailureTime',15)
        case 2
            myArsset('BE1','RepairTime',20)
        case 3
            myArsset('BE2','RepairTime',25)
        case 4
            myArsset('BE3','FailureTime',30)
        case 5
            myArsset('BE4','FailureTime',35)
        case 6
            myArsset('BE1','FailureTime',40)
        case 7
            myArsset('BE3','RepairTime',45)
        case 8
            myArsset('BE6','FailureTime',50)
        case 9
            myArsset('BE1','RepairTime',55)
        case 10
            myArsset('BE5','RepairTime',55)
        case 11
            myArsset('BE6','RepairTime',65)
        case 12
            myArsset('BE1','FailureTime',65)
        case 13
            myArsset('BE5','FailureTime',70)
        case 14
            myArsset('BE7','FailureTime',72)
        otherwise
            nextEventTime = Inf;
            nextEvents = [];
            nextEvent = Inf;
            currentTime = Inf;
    end