function [] = TestDesign()
    BEs = evalin('base', 'BEs');
    GATEs = evalin('base', 'GATEs');
    
    phase = evalin('base', 'phase');
    switch phase
    %% this section must be updated to implement the test
        case 0
            myArsset('BE2','FailureTime',10)
            myArsset('BE5','Status',1)
            myArsset('BE5','LastStatusChange',10)
        case 1
            myArsset('BE6','FailureTime',15)
        case 2
            myArsset('BE7','FailureTime',20)
            myArsset('BE3','Status',1)
            myArsset('BE3','LastStatusChange',20)
        case 3
            myArsset('BE8','FailureTime',25)
            myArsset('BE5','Status',0)
            myArsset('BE5','LastStatusChange',25)
        case 4
            myArsset('BE4','FailureTime',30)
        case 5
            myArsset('BE7','RepairTime',35)
            myArsset('BE2','Status',0)
            myArsset('BE2','LastStatusChange',35)
        case 6
            myArsset('BE5','FailureTime',40)
            myArsset('BE4','Status',0)
            myArsset('BE4','LastStatusChange',40)
        case 7
            myArsset('BE6','FailureTime',45)
            myArsset('BE7','Status',1)
            myArsset('BE7','LastStatusChange',45)
        case 8
            myArsset('BE3','RepairTime',50)
        case 9
            myArsset('BE2','FailureTime',55)
        otherwise
            nextEventTime = Inf;
            nextEvents = [];
            nextEvent = Inf;
            currentTime = Inf;
    end