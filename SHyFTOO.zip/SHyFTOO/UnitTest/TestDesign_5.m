function [] = TestDesign()
    BEs = evalin('base', 'BEs');
    GATEs = evalin('base', 'GATEs');
    
    phase = evalin('base', 'phase');
    switch phase
    %% this section must be updated to implement the test
        case 0
            myArsset('BE3','FailureTime',10)
        case 1
            myArsset('BE6','FailureTime',15)
        case 2
            myArsset('BE4','FailureTime',20)
        case 3
            myArsset('BE2','FailureTime',25)
        case 4
            myArsset('BE3','RepairTime',30)
        case 5
            myArsset('BE7','FailureTime',30)
        case 6
            myArsset('BE3','FailureTime',35)
        case 7
            myArsset('BE4','FailureTime',40)
        case 8
            myArsset('BE5','FailureTime',45)
        otherwise
            nextEventTime = Inf;
            nextEvents = [];
            nextEvent = Inf;
            currentTime = Inf;
    end