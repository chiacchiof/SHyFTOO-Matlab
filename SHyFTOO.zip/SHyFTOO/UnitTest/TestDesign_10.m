function [] = TestDesign()
    BEs = evalin('base', 'BEs');
    GATEs = evalin('base', 'GATEs');
    
    phase = evalin('base', 'phase');
    switch phase
    %% this section must be updated to implement the test
        case 0
            myArsset('BE1','FailureTime',10)
            myArsset('BE7','Status',1)
            myArsset('BE7','LastStatusChange',10)
        case 1
            myArsset('BE3','FailureTime',15)
            myArsset('BE8','Status',1)
            myArsset('BE8','LastStatusChange',15)
        case 2
            myArsset('BE1','RepairTime',20)
            myArsset('BE9','Status',1)
            myArsset('BE9','LastStatusChange',20)
        case 3
            myArsset('BE7','RepairTime',25)
        case 4
            myArsset('BE10','FailureTime',30)
        case 5
            myArsset('BE2','FailureTime',35)
            myArsset('BE4','Status',1)
            myArsset('BE4','LastStatusChange',35)
        case 6
            myArsset('BE6','FailureTime',40)
            myArsset('BE1','Status',1)
            myArsset('BE1','LastStatusChange',40)
        otherwise
            nextEventTime = Inf;
            nextEvents = [];
            nextEvent = Inf;
            currentTime = Inf;
    end