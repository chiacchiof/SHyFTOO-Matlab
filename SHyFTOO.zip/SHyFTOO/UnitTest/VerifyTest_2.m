function [] = VerifyTest()
    phase = evalin('base', 'phase');
    FT = evalin('base','FT');
    nextEvents = evalin('base', 'nextEvents');
    nextEventTimeTest = evalin('base', 'nextEventTimeTest');
    switch (phase-1)
            case 0
                myAssert('OR1','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('SPARE2','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('SPARE1','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('SEQ1','InUseBy', 'SPARE1.Index', nextEventTimeTest);
            case 1
                myAssert('SPARE1','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('SPARE2','Status', 'Constants.BAD', nextEventTimeTest);
                myAssert('OR1','Status', 'Constants.BAD', nextEventTimeTest);
                myAssert('SEQ1','InUseBy', 'SPARE1.Index', nextEventTimeTest);
            case 2
                myAssert('SPARE1','Status', 'Constants.GOOD', nextEventTimeTest); %wrong
                myAssert('SPARE2','Status', 'Constants.BAD', nextEventTimeTest);
                myAssert('OR1','Status', 'Constants.BAD', nextEventTimeTest);
                myAssertLess('BE3','FailureTime', 'Inf', nextEventTimeTest);
                myAssert('SEQ1','InUseBy', 'SPARE1.Index', nextEventTimeTest);
            case 3
                myAssert('OR1','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('SPARE2','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('SPARE1','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssertLess('BE3','FailureTime', 'Inf', nextEventTimeTest);
                myAssert('SEQ1','InUseBy', 'SPARE2.Index', nextEventTimeTest);
            case 4
                myAssert('OR1','Status', 'Constants.BAD', nextEventTimeTest);
                myAssert('SEQ1','Status', 'Constants.BAD', nextEventTimeTest);
                myAssert('SPARE2','Status', 'Constants.BAD', nextEventTimeTest);
                myAssert('SPARE1','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('SEQ1','InUseBy', 'Constants.MINUSONE', nextEventTimeTest);
    end
end