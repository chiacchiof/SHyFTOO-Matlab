function [] = VerifyTest()
    phase = evalin('base', 'phase');
    FT = evalin('base','FT');
    nextEvents = evalin('base', 'nextEvents');
    nextEventTimeTest = evalin('base', 'nextEventTimeTest');
    switch (phase-1)
            case 0
                myAssert('OR1','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('BE2','FailureTime', 'Inf', nextEventTimeTest);
                myAssert('SEQ1','Status', 'Constants.GOOD', nextEventTimeTest);           
    end
end