
%% Define the Fault Tree Structure %%
Tm = 500; %[h]

%% Define BEs %%

BE1 = BasicEvent('BE1','exp','exp',[0.01],[0.05]);
BE2 = BasicEvent('BE2','exp','exp',[0.01],[0.05]);
BE3 = BasicEvent('BE3','exp','exp',[0.008],[0.05]);
BE4 = BasicEvent('BE4','exp','exp',[0.005],[0.05]);
BE5 = BasicEvent('BE5','exp','exp',[0.006],[0.05],'cold',[]);
BE6 = BasicEvent('BE6','exp','exp',[0.01],[0.05]);
BE7 = BasicEvent('BE7','exp','exp',[0.007],[0.05]);

% %% Define Gates %%
SEQ1 = Gate ('SEQ1', 'SEQ', false, [BE3, BE4]);
FDEP1 = Gate ('FDEP1', 'FDEP', false, [BE1, BE2]);
SPARE1 = Gate ('SPARE1', 'SPARE', false, [BE2, SEQ1], [BE5]);
OR1 = Gate ('OR1', 'OR', false, [BE6, SEQ1, BE7]);
AND1 = Gate ('AND1', 'AND', false, [BE1, SPARE1]);
PAND1 = Gate ('PAND1', 'PAND', false, [AND1, OR1]);
TOP = PAND1;
%% Recall Matlab Script %%
%verify if the FT Structure is valid (it will modify the value of the variable UNVALID_FT)
createFTStructure

