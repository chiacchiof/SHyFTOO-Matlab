function [] = VerifyTest()
    phase = evalin('base', 'phase');
    FT = evalin('base','FT');
    nextEvents = evalin('base', 'nextEvents');
    nextEventTimeTest = evalin('base', 'nextEventTimeTest');
    switch (phase-1)
            case 0
                myAssert('SPARE2','Status', 'Constants.GOOD', nextEventTimeTest);
            case 1
                myAssert('OR2','Status', 'Constants.BAD', nextEventTimeTest);
                myAssert('BE9','Status', 'Constants.BAD', nextEventTimeTest);
                myAssert('OR1','Status', 'Constants.BAD', nextEventTimeTest);
                myAssert('SPARE2','Status', 'Constants.BAD', nextEventTimeTest);
                myAssert('SEQ1','Status', 'Constants.GOOD', nextEventTimeTest);
            
    end
end