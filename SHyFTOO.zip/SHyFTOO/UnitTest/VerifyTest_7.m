function [] = VerifyTest()
    phase = evalin('base', 'phase');
    FT = evalin('base','FT');
    nextEvents = evalin('base', 'nextEvents');
    nextEventTimeTest = evalin('base', 'nextEventTimeTest');
    switch (phase-1)
            case 0
                myAssert('SPARE1','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('SPARE2','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('SEQ1','InUseBy', 'SPARE1.Index', nextEventTimeTest);
                myAssert('PAND1','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('AND1','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('BE3','FailureTime', 'Inf', nextEventTimeTest);
                myAssert('BE4','FailureTime', 'Inf', nextEventTimeTest);
            case 1
                myAssert('SPARE1','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('SPARE2','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('SEQ1','InUseBy', 'SPARE1.Index', nextEventTimeTest);
                myAssert('PAND1','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('AND1','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('BE4','FailureTime', 'Inf', nextEventTimeTest);
            case 2
                myAssert('SPARE1','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('SPARE2','Status', 'Constants.BAD', nextEventTimeTest);
                myAssert('SEQ1','InUseBy', 'SPARE1.Index', nextEventTimeTest);
                myAssert('PAND1','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('AND1','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('BE4','FailureTime', 'Inf', nextEventTimeTest);
            case 3
                myAssert('SPARE1','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('SPARE2','Status', 'Constants.BAD', nextEventTimeTest);
                myAssert('SEQ1','InUseBy', 'SPARE1.Index', nextEventTimeTest);
                myAssert('PAND1','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('AND1','Status', 'Constants.GOOD', nextEventTimeTest);
            case 4
                myAssert('SPARE1','Status', 'Constants.BAD', nextEventTimeTest);
                myAssert('SPARE2','Status', 'Constants.BAD', nextEventTimeTest);
                myAssert('SEQ1','Status', 'Constants.BAD', nextEventTimeTest);
                myAssert('SEQ1','InUseBy', 'Constants.MINUSONE', nextEventTimeTest);
                myAssert('PAND1','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('AND1','Status', 'Constants.GOOD', nextEventTimeTest);
            case 5
                myAssert('SPARE1','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('SPARE2','Status', 'Constants.BAD', nextEventTimeTest);
                myAssert('SEQ1','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('SEQ1','InUseBy', 'SPARE1.Index', nextEventTimeTest);
                myAssert('PAND1','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('AND1','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('BE2','Status', 'Constants.BAD', nextEventTimeTest);
                myAssert('BE4','Status', 'Constants.GOOD', nextEventTimeTest);
            case 6
                myAssert('SPARE1','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('SPARE2','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('SEQ1','InUseBy', 'SPARE2.Index', nextEventTimeTest);
                myAssert('PAND1','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('AND1','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('BE4','FailureTime', 'Inf', nextEventTimeTest);
            case 7
                myAssert('SPARE1','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('SPARE2','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('SEQ1','InUseBy', 'SPARE2.Index', nextEventTimeTest);
                myAssert('PAND1','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('AND1','Status', 'Constants.GOOD', nextEventTimeTest);
            case 8
                myAssert('SPARE1','Status', 'Constants.BAD', nextEventTimeTest);
                myAssert('SPARE2','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('SEQ1','InUseBy', 'SPARE2.Index', nextEventTimeTest);
                myAssert('PAND1','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('AND1','Status', 'Constants.GOOD', nextEventTimeTest);
            case 9
                myAssert('SPARE1','Status', 'Constants.BAD', nextEventTimeTest);
                myAssert('SPARE2','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('SEQ1','InUseBy', 'SPARE2.Index', nextEventTimeTest);
                myAssert('PAND1','Status', 'Constants.BAD', nextEventTimeTest);
                myAssert('AND1','Status', 'Constants.GOOD', nextEventTimeTest);
            case 10
                myAssert('SPARE1','Status', 'Constants.BAD', nextEventTimeTest);
                myAssert('SPARE2','Status', 'Constants.BAD', nextEventTimeTest);
                myAssert('SEQ1','InUseBy', 'Constants.MINUSONE', nextEventTimeTest);
                myAssert('SEQ1','Status', 'Constants.BAD', nextEventTimeTest);
                myAssert('PAND1','Status', 'Constants.BAD', nextEventTimeTest);
                myAssert('AND1','Status', 'Constants.BAD', nextEventTimeTest);
    end
end