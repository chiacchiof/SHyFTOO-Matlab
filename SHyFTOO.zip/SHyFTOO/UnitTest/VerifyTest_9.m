function [] = VerifyTest()
    phase = evalin('base', 'phase');
    FT = evalin('base','FT');
    nextEvents = evalin('base', 'nextEvents');
    nextEventTimeTest = evalin('base', 'nextEventTimeTest');
    switch (phase-1)
            case 0
                myAssert('SPARE1','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('OR1','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssertLess('BE4','FailureTime', 'Inf', nextEventTimeTest);
                myAssert('BE5','FailureTime', 'Inf', nextEventTimeTest);
            case 1
                myAssert('SPARE2','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('SPARE3','Status', 'Constants.BAD', nextEventTimeTest);
                myAssert('BE5','InUseBy', 'SPARE2.Index', nextEventTimeTest);
                myAssert('OR1','Status', 'Constants.BAD', nextEventTimeTest);
                myAssert('AND1','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('BE6','RepairTime', 'Inf', nextEventTimeTest);
                myAssert('BE8','RepairTime', 'Inf', nextEventTimeTest);
            case 2
                myAssert('SPARE1','Status', 'Constants.BAD', nextEventTimeTest);
                myAssert('SEQ1','Status', 'Constants.BAD', nextEventTimeTest);
                myAssert('SEQ1','InUseBy', 'Constants.MINUSONE', nextEventTimeTest);
                myAssert('AND2','Status', 'Constants.BAD', nextEventTimeTest);
                myAssert('AND1','Status', 'Constants.BAD', nextEventTimeTest);
            case 3
                myAssert('AND2','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('AND1','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('BE5','InUseBy', 'SPARE2.Index', nextEventTimeTest);
                myAssert('SPARE2','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('OR1','Status', 'Constants.BAD', nextEventTimeTest);
                myAssertLess('BE6','RepairTime', 'Inf', nextEventTimeTest);
                myAssertLess('BE8','RepairTime', 'Inf', nextEventTimeTest);
            case 4
                myAssert('SPARE2','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('BE5','InUseBy', 'SPARE3.Index', nextEventTimeTest);
                myAssert('OR1','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('SPARE1','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('SPARE3','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('SEQ1','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('BE4','FailureTime', 'Inf', nextEventTimeTest);
            case 5
                myAssert('SPARE3','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('OR1','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('AND2','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('AND1','Status', 'Constants.GOOD', nextEventTimeTest);
            case 6
                myAssert('SPARE1','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssertLess('BE4','FailureTime', 'Inf', nextEventTimeTest);
                myAssert('SPARE2','Status', 'Constants.BAD', nextEventTimeTest);
                myAssert('SPARE3','Status', 'Constants.BAD', nextEventTimeTest);
                myAssert('AND2','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('OR1','Status', 'Constants.BAD', nextEventTimeTest);
                myAssert('AND1','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('BE6','RepairTime', 'Inf', nextEventTimeTest);
                myAssert('BE8','RepairTime', 'Inf', nextEventTimeTest);
            case 7
                myAssert('SPARE1','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('SPARE2','Status', 'Constants.BAD', nextEventTimeTest);
                myAssert('BE5','InUseBy', 'SPARE1.Index', nextEventTimeTest);
                myAssert('SPARE3','Status', 'Constants.BAD', nextEventTimeTest);
                myAssert('AND2','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('AND1','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('OR1','Status', 'Constants.BAD', nextEventTimeTest);
    end
end