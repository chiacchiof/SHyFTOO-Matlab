function [] = VerifyTest()
    phase = evalin('base', 'phase');
    FT = evalin('base','FT');
    nextEvents = evalin('base', 'nextEvents');
    nextEventTimeTest = evalin('base', 'nextEventTimeTest');
    switch (phase-1)
            case 0
                myAssert('SPARE1','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('SPARE2','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('SEQ1','InUseBy', 'SPARE1.Index', nextEventTimeTest);
                myAssert('OR2','Status', 'Constants.BAD', nextEventTimeTest);
                myAssert('PAND2','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('PAND1','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('OR1','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssertLess('BE6','FailureTime', 'Inf', nextEventTimeTest);
            case 1
                myAssert('SPARE1','Status', 'Constants.BAD', nextEventTimeTest);
                myAssert('SPARE2','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('SEQ1','InUseBy', 'Constants.MINUSONE', nextEventTimeTest);
                myAssert('SEQ1','Status', 'Constants.BAD', nextEventTimeTest);
                myAssert('OR2','Status', 'Constants.BAD', nextEventTimeTest);
                myAssert('PAND2','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('PAND1','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('OR1','Status', 'Constants.GOOD', nextEventTimeTest);
            case 2
                myAssert('SPARE1','Status', 'Constants.BAD', nextEventTimeTest);
                myAssert('SPARE2','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('SEQ1','Status', 'Constants.BAD', nextEventTimeTest);
                myAssert('BE8','InUseBy', 'SPARE2.Index', nextEventTimeTest);
                myAssert('OR2','Status', 'Constants.BAD', nextEventTimeTest);
                myAssert('PAND2','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('PAND1','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('OR1','Status', 'Constants.GOOD', nextEventTimeTest);
            case 3
                myAssert('SPARE1','Status', 'Constants.BAD', nextEventTimeTest);
                myAssert('SPARE2','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('SEQ1','InUseBy', 'SPARE2.Index', nextEventTimeTest);
                myAssert('BE6','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('BE6','FailureTime', 'Inf', nextEventTimeTest);
                myAssert('PAND2','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('PAND1','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('OR1','Status', 'Constants.GOOD', nextEventTimeTest);
            case 4
                myAssert('PAND2','Status', 'Constants.BAD', nextEventTimeTest);
                myAssert('AND1','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('PAND1','Status', 'Constants.GOOD', nextEventTimeTest);
            case 5
                myAssert('SPARE1','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('SPARE2','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('SEQ1','InUseBy', 'SPARE1.Index', nextEventTimeTest);
                myAssert('PAND2','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('PAND1','Status', 'Constants.GOOD', nextEventTimeTest);
            case 6
                myAssert('SPARE1','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssertLess('BE6','FailureTime', 'Inf', nextEventTimeTest);
                myAssert('SEQ1','InUseBy', 'SPARE1.Index', nextEventTimeTest);
                myAssert('AND1','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('PAND1','Status', 'Constants.GOOD', nextEventTimeTest);
            case 7
                myAssert('SPARE1','Status', 'Constants.BAD', nextEventTimeTest);
                myAssert('SPARE2','Status', 'Constants.BAD', nextEventTimeTest);
                myAssert('SEQ1','InUseBy', 'Constants.MINUSONE', nextEventTimeTest);
                myAssert('SEQ1','Status', 'Constants.BAD', nextEventTimeTest);
                myAssert('PAND1','Status', 'Constants.BAD', nextEventTimeTest);
                myAssert('PAND2','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('OR1','Status', 'Constants.BAD', nextEventTimeTest);
            case 8
                myAssert('SPARE1','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('SPARE2','Status', 'Constants.BAD', nextEventTimeTest);
                myAssert('OR2','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('PAND1','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('PAND2','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('OR1','Status', 'Constants.GOOD', nextEventTimeTest);
            case 9
                myAssert('SPARE1','Status', 'Constants.BAD', nextEventTimeTest);
                myAssert('OR2','Status', 'Constants.BAD', nextEventTimeTest);
                myAssert('PAND1','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('PAND2','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('OR1','Status', 'Constants.GOOD', nextEventTimeTest);
    end
end