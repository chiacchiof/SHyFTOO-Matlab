function [] = TestDesign()
    BEs = evalin('base', 'BEs');
    GATEs = evalin('base', 'GATEs');
    
    phase = evalin('base', 'phase');
    switch phase
    %% this section must be updated to implement the test
        case 0
            myArsset('BE2','FailureTime',10)
        case 1
            myArsset('BE4','FailureTime',15)
        case 2
            myArsset('BE5','FailureTime',20)
        case 3
            myArsset('BE2','RepairTime',25)
            myArsset('BE3','FailureTime',30)
        case 4
            myArsset('BE3','FailureTime',30)
        otherwise
            nextEventTime = Inf;
            nextEvents = [];
            nextEvent = Inf;
            currentTime = Inf;
    end