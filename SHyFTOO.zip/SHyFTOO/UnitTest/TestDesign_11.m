function [] = TestDesign()
    BEs = evalin('base', 'BEs');
    GATEs = evalin('base', 'GATEs');
    
    phase = evalin('base', 'phase');
    switch phase
    %% this section must be updated to implement the test
        case 0
            myArsset('BE6','FailureTime',10)
        case 1
            myArsset('BE7','FailureTime',15)
        
        otherwise
            nextEventTime = Inf;
            nextEvents = [];
            nextEvent = Inf;
            currentTime = Inf;
    end