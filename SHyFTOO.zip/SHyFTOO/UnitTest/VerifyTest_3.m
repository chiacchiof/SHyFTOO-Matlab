function [] = VerifyTest()
    phase = evalin('base', 'phase');
    FT = evalin('base','FT');
    nextEvents = evalin('base', 'nextEvents');
    nextEventTimeTest = evalin('base', 'nextEventTimeTest');
    switch (phase-1)
            case 0
                myAssert('OR1','Status', 'Constants.BAD', nextEventTimeTest);
                myAssert('AND1','Status', 'Constants.GOOD', nextEventTimeTest);
            case 1
                myAssert('AND1','Status', 'Constants.BAD', nextEventTimeTest);
                myAssert('OR1','Status', 'Constants.BAD', nextEventTimeTest);
            case 2
                myAssert('OR1','Status', 'Constants.GOOD', nextEventTimeTest);
                myAssert('AND1','Status', 'Constants.GOOD', nextEventTimeTest);
    end
end