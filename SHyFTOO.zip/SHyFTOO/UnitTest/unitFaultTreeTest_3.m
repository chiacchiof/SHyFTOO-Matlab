
%% Define the Fault Tree Structure %%
Tm = 500; %[h]

%% Define BEs %%

BE1 = BasicEvent('BE1','exp','exp',[0.01],[0.05]);
BE2 = BasicEvent('BE2','exp','exp',[0.01],[0.05]);
BE3 = BasicEvent('BE3','exp','exp',[0.008],[0.05]);

% %% Define Gates %%
OR1 = Gate ('OR1', 'OR', false, [BE1, BE2]);
AND1 = Gate ('AND1', 'AND', false, [BE3, OR1]);
TOP = AND1;
%% Recall Matlab Script %%
%verify if the FT Structure is valid (it will modify the value of the variable UNVALID_FT)
createFTStructure

