alfa3_b = 120000000; % [h], average life of bearings (power of 3) 
alfa_w = 93000; % [h],  average life of coil
QI = 1; % input vector of the input flow-rate
VI = 0; % set the initial value of the volume of the distillation column
aging = 0;
%% iteration starts
for (currentTime=1:Tm)
    if TOP.Status == Constants.GOOD
        aging = aging + 1;
    else
        aging = 0;
    end
    HBE2.FailureArgs = (1/10+((aging)^2)/120)*10^-4; % update the failure rate of HBE2
    evaluateHybrid;
    PHevaluateFT;
    QU = QI*abs(TOP.Status-1); % output flow-rate
    if currentTime > 1
        VI(currentTime) = VI(currentTime-1) + QU; % update the volume of the distillation column 
    else
        VI(currentTime) = QU;
    end
end
