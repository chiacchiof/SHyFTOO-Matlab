clear all; %to modify to clear only PROGRAMS variables
addpath(genpath(pwd));
tic
load('workspace_great.mat');
for counter_i=counter_i:iter
    if(~stopCriteriaMet)
        reinit;
        while(nextEventTime<Tm) 
            ZFTAevaluateFT;
        end
        computeUpTime;
        updateNFailure;
        if(stopCriteriaOn)
            verifyStopCriteria; 
        end
       % disp(counter_i);
    else
        toc
        return;
    end
    if(mod(counter_i,100000)==0)
        save('workspace_great');
    end
end
toc

