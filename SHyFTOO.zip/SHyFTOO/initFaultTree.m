
%% Define the Fault Tree Structure %%
Tm = 8760; %[h]

%% Define BEs %%

HBE1 = BasicEvent('HBE1','exp','',[1.64e-4],[1/135]); %process sensors
HBE2 = BasicEvent('HBE2','exp','',[1.64e-4],[1/135],'',[5.0000e-07]);
BE3 = BasicEvent('BE3','exp','',[1.19e-4],[1/135]);

% %% Define Gates %%

SPARE1 = Gate ('SPARE1', 'SPARE', false, [HBE1], [HBE2]);
OR1 = Gate ('OR3', 'OR', false, [BE3, SPARE1]);

TOP = OR1;

%% Define exit criteria: 1. Top.IsFailureGate = true -> reliability, 2. otherwise -> "uptime" 
TOP.IsFailureGate = true;

%% Recall Matlab Script %%
%verify if the FT Structure is valid (it will modify the value of the variable UNVALID_FT)
createFTStructure
