clear all; %to modify to clear only PROGRAMS variables

addpath(genpath(pwd));
tic
iter = 1;
inputFullFileNameRound = fullfile(pwd, '\src\func\zround.m');
outputFullFileNameRound = fullfile(pwd, '\src\func\rround.m');
copyfile (inputFullFileNameRound, outputFullFileNameRound);
clear inputFullFileNameRound outputFullFileNameRound;
TimeStep = Constants.TIMESTEP;
debugMode = false;

%retrieve testing files in directory UnitTest (each UnitTest is composed of 3 files)
listing = dir(strcat(pwd,'\UnitTest\*.m'));
nFiles2Test = length(listing)/3; 

for(nTestCounter=1:nFiles2Test)
    clearvars -except nFiles2Test debugMode TimeStep iter nTestCounter
    
    UNVALID_FT = 0; % 0, FT is valid (1 otherwise) This check is performed inside the "initFaultTree" script.
    rng('shuffle')
    failureTime = zeros(1,iter);
    currentTime = 0;
    counter_i = 1;
    unitFaultTreeTest = strcat('unitFaultTreeTest_',string(nTestCounter));
    unitTestDesign = strcat('TestDesign_',string(nTestCounter));
    verifyTestFun = strcat('VerifyTest_', string(nTestCounter));
    
    %% Debug Mode
    if debugMode
       debugLogFile = createDebugMode; %return the ID to the debug file
    end
    %%

    eval(unitFaultTreeTest);

    %% Init Test%
    
    phase = 0;
    [currentTime, nextEvents, nextEvent, nextEventTime] = UnitTest(unitTestDesign);
    nextEventTimeTest = nextEventTime;
    phase = phase +1;

    %% 
    if (UNVALID_FT)
        return
    end

    ttfComponents = zeros(counterComponents-1,iter);
    while(nextEventTime<Tm) 
        ZFTAevaluateFT;
        %% Verify Test%
        feval(verifyTestFun);
        %% Reinit Test%
        [currentTime, nextEvents, nextEvent, nextEventTime] = UnitTest(unitTestDesign);
        nextEventTimeTest = nextEventTime;
        phase = phase + 1;
        %test
    end
    nTestCounter;
    
end    
    
toc

