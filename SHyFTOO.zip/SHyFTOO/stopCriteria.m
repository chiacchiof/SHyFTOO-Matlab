N = 100000;
ConfidenceLevel = 0.95;
Zvalue = norminv(1-((1-ConfidenceLevel)/2));
i_result = zeros(1,N);
muX =  zeros(1,N);
err_i = zeros(1,N);
err_vect = zeros(1,N);
for(i=1:N)
    x = 0.00001*rand(1);
    i_result(i) = x;
    if(i>1)
        muX(i) = sum(i_result(1,1:i))/i;
        accepted_error = muX(i)*0.01 ;
        err_i(i) = (x - muX(i))^2;
        varX = (1/(i-1))*sum(err_i(1,1:i));
        err = (Zvalue*1.2*varX^0.5)/i^0.5;
        err_vect(i) = err;
        if err<=accepted_error
            return;
        end
    end
end