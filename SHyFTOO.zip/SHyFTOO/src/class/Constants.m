classdef Constants
  
    properties (Constant)
      AND = 'AND';
      OR = 'OR';
      PAND = 'PAND';
      SPARE = 'SPARE';
      FDEP = 'FDEP';
      VOTING = 'VK';
      SEQ = 'SEQ';

      
      INF = inf;
      MINUSONE = -1;
      GOOD = 0;
      BAD = 1;
      
      HOT = 0;
      WARM = 1;
      COLD = 2;
      
      TIMESTEP = 1;
      SIMULATION_TIME = 1000;
      
    end
end
        
        