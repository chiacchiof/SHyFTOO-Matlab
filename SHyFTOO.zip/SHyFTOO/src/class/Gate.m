classdef Gate < BasicElement
    
    properties
        Type;
        Inputs;
        Spares;
        IsFailureGate;
    end
    
    methods
        function gobj = Gate (name, type, isFailure, inputBE, inputSPARE)
            gobj = gobj@BasicElement();
            gobj.Type = type;
            gobj.Inputs = inputBE;
            gobj.Name = name;
            gobj.IsFailureGate = isFailure;
            switch nargin
                case 5
                    gobj.Spares = inputSPARE;
                otherwise
                    gobj.Spares = NaN;
            end
        end
        
        function value = IsEmptySpares(obj)
            value = true;
            if (length(obj.Spares)>0)
                if (strcmp(class(obj.Spares(1)), 'BasicEvent') || strcmp(class(obj.Spares(1)),'Gate'))
                    value = false;
                end
            end
        end
        
        function value = IsEmptyInputs(obj)
            value = true;
            if (length(obj.Inputs)>0)
                if (strcmp(class(obj.Inputs(1)), 'BasicEvent') || strcmp(class(obj.Inputs(1)),'Gate'))
                    value = false;
                end
            end
        end
        
        % returns an array of the inputs status with respective event time
        function value = ArrayStatusInputs(obj, currentTime)
            value = [];
            for(i=1:length(obj.Inputs))
                if(strcmp(class(obj.Inputs(i)), 'BasicEvent'))
                    status = obj.Inputs(i).Status;
                    lastChange = obj.Inputs(i).LastStatusChange;
                    value = [value, [status; lastChange]];
                else
                    value = [value, obj.Inputs(i).ComputeStatus(currentTime)];
                end
            end
        end

        % returns an array of the spare status with respective event time
        function value = ArrayStatusSpares(obj, currentTime)
            value = [];
            for(i=1:length(obj.Spares))
                if(strcmp(class(obj.Spares(i)), 'BasicEvent'))
                    status = obj.Spares(i).Status;
                    lastChange = obj.Spares(i).LastStatusChange;
                    value = [value, [status; lastChange]];
                else
                    value = [value, obj.Spares(i).ComputeStatus(currentTime)];
                end
            end
        end

        function value = NumOfSpareServed(obj, currentTime)
            value = 0;
            for(i=1:length(obj.Spares))
                if (obj.Spares(i).InUseBy == obj.Index)
                    value = value + 1;
                end
            end
        end
        
        function value = PrimaryInputFDEPFailed (obj)
            value = false;
            %evaluate if the Gate is among the secondary input of a FDEP
            %if YES and the Primary of FDEP is broken the gate does not
            %need to be evaluated because has been set as BAD
            for(i=1:length(obj.InputOf))
                if (strcmp(obj.InputOf(i).Type,'FDEP'))
                    %if the primary of the FDEP is BAD, the GATE is Failed
                    % All the status info have been updated in the FDEP section
                    if(obj.InputOf(i).Inputs(1).Status == Constants.BAD)
                        value = true;
                        break;
                    end
                end
            end
        end
        
        function value = EvalGateBehaviour (obj, currentTime)
            statusInputs = obj.ArrayStatusInputs(currentTime); %this must be evaluated in any case 
            if (strcmp(obj.Type,Constants.AND))
                if(~obj.IsFailureGate || obj.Status == Constants.GOOD) %consider FailureGate behaviour
                    if(prod(statusInputs(1,:))~=obj.Status)
                        obj.LastStatusChange = currentTime;
                        obj.Status = abs(Constants.BAD-obj.Status);
                    end
                end
            elseif (strcmp(obj.Type,Constants.OR))
                if(~obj.IsFailureGate || obj.Status == Constants.GOOD) %consider FailureGate behaviour
                    if((sum(statusInputs(1,:))>0)~=obj.Status)
                        obj.LastStatusChange = currentTime;
                        obj.Status = abs(Constants.BAD-obj.Status);
                    end
                end
            elseif (strcmp(obj.Type(1:end-1),Constants.VOTING)) %VOTING: VKx means that x out of n(number of inputs) must be BAD
                %eg. VK3: 3 out of n must be BAD
                if(~obj.IsFailureGate || obj.Status == Constants.GOOD) %consider FailureGate behaviour
                    req4Fail = str2double(obj.Type(end));
                    if((sum(statusInputs(1,:))>=req4Fail)~=obj.Status)
                        obj.LastStatusChange = currentTime;
                        obj.Status = abs(Constants.BAD-obj.Status);
                    end
                end
            elseif (strcmp(obj.Type,Constants.PAND))
                tempStatus = obj.Status;
                if(~obj.IsFailureGate || obj.Status == Constants.GOOD) %consider FailureGate behaviour
                    if(prod(statusInputs(1,:)))
                        for(i=length(statusInputs):-1:2)
                            if(statusInputs(2,i)< statusInputs(2,i-1))
                                obj.Status = Constants.GOOD;
                                break;
                            end
                            obj.Status = Constants.BAD;
                        end
                    else
                        obj.Status = Constants.GOOD;
                    end
                    %if the status has changed, modify the LastStatusChange
                    if(tempStatus~=obj.Status)
                        obj.LastStatusChange = currentTime;
                    end
                end
            %the failure behaviour of the SEQ and PAND Gate is the same!
            elseif (strcmp(obj.Type,Constants.SEQ))
                tempStatus = obj.Status;
                if(~obj.IsFailureGate || obj.Status == Constants.GOOD) %consider FailureGate behaviour
                    if(prod(statusInputs(1,:)))
                        for(i=length(statusInputs):-1:2)
                            if(statusInputs(2,i)< statusInputs(2,i-1))
                                obj.Status = Constants.GOOD;
                                break;
                            end
                            obj.Status = Constants.BAD;
                        end
                    else
                        obj.Status = Constants.GOOD;
                    end
                    %if the status has changed, modify the LastStatusChange
                    if(tempStatus~=obj.Status)
                        obj.LastStatusChange = currentTime;
                    end
                end
            elseif (strcmp(obj.Type,Constants.SPARE))
                numOfSpareServed = obj.NumOfSpareServed(currentTime);        
                statusSpares = obj.ArrayStatusSpares(currentTime); %this must be called in order to revaluate the status of the spare input
                tempStatus = obj.Status; %save the current status (before any possible change)
                nSpares = length(obj.Spares);
                %notFailedSpares = nSpares - sum(statusSpares(1,:)); IS IT NEEDED??
                if(~obj.IsFailureGate || obj.Status == Constants.GOOD) %consider FailureGate behaviour
                    nInputsFailed = sum(statusInputs(1,:));
                    %if nInputsFailed == 0 the status of the GATE is GOOD
                    %Skip all the other part of the algorithm
                    if(numOfSpareServed-nInputsFailed == 0)
                        obj.Status = Constants.GOOD;
                    % if the number of spares is less than the input failed there is no point to continue allocating spares to the resource
                    elseif (nSpares<nInputsFailed) %elseif (notFailedSpares<nInputsFailed)
                        obj.Status = Constants.BAD;
                        %preset the status before to verify if spare components save the gate
                    else
                        obj.Status = Constants.BAD;
                        %verify if spare components save the gate
                        for(i=1:nSpares)
                            %verify if the Spare Inputs are good and if are currently in use by the gate
                            if(obj.Spares(i).Status == Constants.GOOD && (obj.Spares(i).InUseBy==Constants.MINUSONE || obj.Spares(i).InUseBy == obj.Index))
                                nInputsFailed = nInputsFailed - 1; %if status is good, decrement nInputsFailed
                                if (obj.Spares(i).InUseBy==Constants.MINUSONE) %if status it was not yet used, allocate to the calling SPARE gate and sample its failure time
                                    obj.Spares(i).InUseBy = obj.Index; % assign the spare component to the gate
                                    %if spare component is a BE and was not yet in use & was COLD, it must be computed the failure time
                                    if(strcmp(class(obj.Spares(i)), 'BasicEvent')) %&& obj.Spares(i).SpareBehaviour == Constants.COLD)
                                        obj.Spares(i).SampleNextEvent(currentTime); %SampleNextEvent will compute the next failure time
                                    end
                                end
                                if nInputsFailed == 0
                                    obj.Status = Constants.GOOD;
                                    break;
                                end
                            end
                        end
                    end
                    %if the status has changed, modify the LastStatusChange
                    if(tempStatus~=obj.Status)
                        obj.LastStatusChange = currentTime;
                    end
                end
            end
            value = [obj.Status; obj.LastStatusChange];
        end
        
        % evaluate the STATUS of the typical fault tree gates
        function value = ComputeStatus (obj, currentTime)
            hasPrimaryFDEPFailed = obj.PrimaryInputFDEPFailed();
            %the gate dont have to be evaluated  if primary of FDEP is BAD
            if (hasPrimaryFDEPFailed)
                dummy = obj.ArrayStatusInputs(currentTime); %but its inputs must be evaluated
                value = [obj.Status; obj.LastStatusChange];
            else
                value = obj.EvalGateBehaviour(currentTime);
            end
        end
        
        % evaluate the STATUS of the typical fault tree gates
        function value = ComputeStatusInFDEP (obj, currentTime)
            value = obj.EvalGateBehaviour(currentTime);
        end
        
    end %close methods section
end %close class section