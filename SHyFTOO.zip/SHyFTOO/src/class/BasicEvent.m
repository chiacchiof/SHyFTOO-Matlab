classdef BasicEvent < BasicElement
    
    properties
        FailureDistribution;
        RepairDistribution;
        FailureArgs;
        RepairArgs;
        FailureWarmDistr;
        FailureWarmArgs;
        SpareBehaviour; %0: Hot, 1: Warm, 2: Cold
        NReplacement %number of times it was succesfully substituted
    end
    
    methods
        function gobj = BasicEvent (name, failureDistro, repairDistro, failureArgs, repairArgs, failureWarmDistr, failureWarmArgs)
            gobj = gobj@BasicElement();
            gobj.FailureDistribution = failureDistro;
            gobj.RepairDistribution = repairDistro;
            gobj.FailureArgs = failureArgs;
            gobj.RepairArgs = repairArgs;
            gobj.Name = name;
            gobj.SpareBehaviour = 0;
            gobj.NReplacement = 0;
            if nargin>=6 % set spare behaviour
                gobj.FailureWarmDistr = failureWarmDistr;
                gobj.FailureWarmArgs = failureWarmArgs;
                if (strcmp(failureWarmDistr,'cold'))
                    gobj.SpareBehaviour = Constants.COLD;
                elseif (strcmp(failureWarmDistr,'hot'))
                    gobj.SpareBehaviour = Constants.HOT;
                else
                    gobj.SpareBehaviour = Constants.WARM;
                end
            end
            gobj.SampleNextEvent(0); % set the first event (failure or repair according to the init status)
        end
        
        function ClearIterationProperty (obj)
            obj.ClearIterationProperty@BasicElement();
            obj.SampleNextEvent(0);
        end
        
        function value = SampleFailureTime (obj, currentTime)
            obj.RepairTime = Constants.INF;
            if (strcmp(obj.FailureDistribution, 'exp'))
                obj.FailureTime = rround(currentTime + Constants.TIMESTEP + expinv(rand, 1/obj.FailureArgs(1)));
            elseif (strcmp(obj.FailureDistribution, 'wei'))
                obj.FailureTime = rround(currentTime + Constants.TIMESTEP + wblinv(rand, obj.FailureArgs(1), obj.FailureArgs(2)));
            else
                obj.FailureTime = Constants.INF;
            end
            value = obj.FailureTime;
        end
        
        function value = SampleWarmFailureTime (obj, currentTime)
            obj.RepairTime = Constants.INF;
            if (strcmp(obj.FailureWarmDistr, 'exp'))
                obj.FailureTime = rround(currentTime + Constants.TIMESTEP + expinv(rand, 1/obj.FailureWarmArgs(1)));
            elseif (strcmp(obj.FailureWarmDistr, 'wei'))
                obj.FailureTime = rround(currentTime + Constants.TIMESTEP + wblinv(rand, obj.FailureWarmArgs(1), obj.FailureWarmArgs(2)));
            else
                obj.FailureTime = Constants.INF;
            end
            value = obj.FailureTime;
        end        
        
        function value = SampleRepairTime (obj, currentTime)
            obj.FailureTime = Constants.INF;
            if (strcmp(obj.RepairDistribution, 'exp'))
                obj.RepairTime = rround(currentTime + Constants.TIMESTEP + expinv(rand, 1/obj.RepairArgs(1)));
            elseif (strcmp(obj.RepairDistribution, 'wei'))
                obj.RepairTime = rround(currentTime + Constants.TIMESTEP + wblinv(rand, obj.RepairArgs(1), obj.RepairArgs(2)));
            else
                obj.RepairTime = Constants.INF;
            end
            value = obj.RepairTime;
        end
        
        
        function value = ComputeStatus (obj, currentTime)
            if(obj.Status == Constants.BAD) %From FAILED to GOOD
                if (currentTime >= obj.RepairTime)
                    obj.Status = Constants.GOOD;
                    obj.NReplacement = obj.NReplacement + 1;
                end
            else
                if (currentTime >= obj.FailureTime) %From GOOD to FAILED
                    obj.Status = Constants.BAD;
                end
            end
            obj.LastStatusChange = currentTime;
            obj.FailureTime = Constants.INF; %reset 
            obj.RepairTime = Constants.INF; %reset
            %% return
            value = obj.Status;
        end    
        
        function value = SampleNextEvent (obj, currentTime)
            if(obj.Status == Constants.BAD)
                value = SampleRepairTime(obj, currentTime);
            else
                if (obj.InUseBy == Constants.MINUSONE && obj.SpareBehaviour ~= Constants.HOT)
                    value = SampleWarmFailureTime(obj, currentTime);
                else
                    value = SampleFailureTime(obj, currentTime);
                end
            end
        end
        
        function SetStatus(obj, status, currentTime)
            obj.SetStatus@BasicElement(status,currentTime);
            if(obj.Status == Constants.GOOD)
                obj.RepairTime = Constants.INF;
            else
                obj.FailureTime = Constants.INF;
            end
        end
        
    end
end