classdef BasicElement < handle & matlab.mixin.Heterogeneous
  
    properties
        %static property = related to FTA (DO NOT change during MonteCarlo)
        %iteration property = related to MonteCarlo -> Reset @ new iter
        %cumulative iteration property = related to MonteCarlo(DO NOT Reset)
        
        Name  %static property 
        InputOf %static property
        SpareOf %static property
        Index %static property 
        FailureTime %iteration property 
        RepairTime %iteration property 
        Status %iteration property 
        LastStatusChange %iteration property 
        InUseBy %iteration property --- for SPARE component identifies the gate that is currently using the element
        EvalInSEQ %iteration property --- for SEQ component identifies if was evaluated in SEQ
        EvalInFDEP %iteration property --- for FEDEP component identifies if was evaluated in FDEP
        EvalInSPARE %iteration property --- for SPARE component identifies if was evaluated in SPARE
        UpTime
        NFailure %cumulative iteration property (==>Reliability)
        TimeOfFailureArray %cumulative iteration property (==>Reliability)
    end
    
    methods

        function gobj = BasicElement ()
            gobj.Status = Constants.GOOD;
            gobj.UpTime = 0;
            gobj.LastStatusChange = 0;
            gobj.RepairTime = Constants.INF;
            gobj.FailureTime = Constants.INF;
            gobj.NFailure = 0;
            gobj.InUseBy = Constants.MINUSONE;
            gobj.EvalInSEQ = false;
            gobj.EvalInFDEP = false;
            gobj.EvalInSPARE = false;
            gobj.TimeOfFailureArray = [];
        end   
        
        %use this method to reset iteration property
        function ClearIterationProperty(obj)
            obj.Status = Constants.GOOD;
            obj.FailureTime = Constants.INF;
            obj.RepairTime = 0;
            obj.Status = 0;
            obj.LastStatusChange = 0;
            obj.EvalInSEQ = false;
            obj.EvalInFDEP = false;
            obj.EvalInSPARE = false;
            obj.InUseBy = Constants.MINUSONE;
        end
        
        function UpdateNFailure(obj, Tm)
            if(obj.Status == 1 && obj.LastStatusChange<Tm)
                obj.NFailure = obj.NFailure + 1;
                obj.TimeOfFailureArray = [obj.TimeOfFailureArray obj.LastStatusChange];
            else
                obj.TimeOfFailureArray = [obj.TimeOfFailureArray inf];
            end
        end
        
        function set.FailureTime (obj, failureTime)
            obj.FailureTime = failureTime;
        end
        
        function set.RepairTime (obj, repairTime)
            obj.RepairTime = repairTime;
        end
        
        function set.Index (obj, index)
            obj.Index = index;
        end
        
        function set.Name (obj, name)
            obj.Name = name;
        end
        
        function set.InputOf (obj, index)
            obj.InputOf = index;
        end
        
        function SetStatus(obj, status, currentTime)
            if(obj.Status~=status)
                obj.LastStatusChange = currentTime;
            end
            obj.Status = status;
        end
        
        function ComputeUpTime (obj, Tm)
            if (obj.Status == Constants.GOOD)
                obj.UpTime = obj.UpTime + Tm - obj.LastStatusChange;
            end
        end
        
        function UpdateUpTime (obj, lastButOneStatus, lastButOneStatusChange, lastStatusChange, currentTime)
            if (lastButOneStatus ~= obj.Status)
                if(obj.Status == Constants.BAD)
                    obj.UpTime = obj.UpTime + currentTime - lastButOneStatusChange;
                end
            end
        end
        
    end
end
        
        