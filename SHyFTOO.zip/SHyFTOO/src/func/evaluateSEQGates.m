function nextEvents = evaluateSEQGates(triggeringElements, nextEvents, FT, tempStatusFT, currentTime)
for i=1:length(triggeringElements)
    for j=1:length(FT(triggeringElements(i)).InputOf)
        if(strcmp(FT(triggeringElements(i)).InputOf(j).Type,Constants.SEQ))
            SEQGate = FT(triggeringElements(i)).InputOf(j);
            indexInSEQ = 0;
            for(n=1:length(SEQGate.Inputs()))
                if(strcmp(SEQGate.Inputs(n).Name,FT(triggeringElements(i)).Name))
                    indexInSEQ = n;
                    break;
                end
            end

            %if the transition is from BAD go to GOOD
            if(SEQGate.Inputs(indexInSEQ).Status == Constants.GOOD)
                %if the triggering input is not the last
                if(indexInSEQ < length(SEQGate.Inputs()))
                    for(m=indexInSEQ+1:length(SEQGate.Inputs()))
                        tempCurrentStatus = tempStatusFT(1,SEQGate.Inputs(m).Index);
                        SEQGate.Inputs(m).Status = Constants.GOOD;
                        if(tempCurrentStatus ~= Constants.GOOD)
                            SEQGate.Inputs(m).LastStatusChange = currentTime;
                        end
                        if(strcmp(class(SEQGate.Inputs(m)),'BasicEvent'))
                            SEQGate.Inputs(m).FailureTime = Constants.INF;
                            SEQGate.Inputs(m).RepairTime = Constants.INF;
                            nextEvents(1,find(nextEvents(2,:)==SEQGate.Inputs(m).Index)) = Constants.INF;
                        end
                    end
                    break; %this break interrupts the loop on "j" index
                end
            %if the transition is from GOOD TO BAD
            else 
                %1. verify if the previous components are GOOD
                if(indexInSEQ>1)
                    settingIndexGood = 0;
                    for(m=indexInSEQ-1:-1:1)
                        if(SEQGate.Inputs(m).Status == Constants.GOOD)
                            settingIndexGood = m;
                            %a good component has been found
                            break;
                        end
                    end
                    %a good component has been found, thus reset to GOOD all the others
                    if(settingIndexGood>0)
                        for(m=settingIndexGood+1:length(SEQGate.Inputs()))
                            tempCurrentStatus = tempStatusFT(1,SEQGate.Inputs(m).Index);
                            SEQGate.Inputs(m).Status = Constants.GOOD;
                            if(tempCurrentStatus ~= Constants.GOOD)
                                SEQGate.Inputs(m).LastStatusChange = currentTime;
                            end
                            if(strcmp(class(SEQGate.Inputs(m)),'BasicEvent'))
                                SEQGate.Inputs(m).FailureTime = Constants.INF;
                                SEQGate.Inputs(m).RepairTime = Constants.INF;
                                nextEvents(1,find(nextEvents(2,:)==SEQGate.Inputs(m).Index)) = Constants.INF;
                            end
                        end
                        break; %this break interrupts the loop on "j" index
                    end
                    %otherwise it was not found a GOOD component before the triggering one
                    if(indexInSEQ < length(SEQGate.Inputs()))
                        if(strcmp(class(SEQGate.Inputs(indexInSEQ+1)),'BasicEvent'))
                            if(SEQGate.Inputs(indexInSEQ+1).FailureTime == Constants.INF && SEQGate.Inputs(indexInSEQ+1).RepairTime == Constants.INF)
                                nextSEQEvent = SEQGate.Inputs(indexInSEQ+1).SampleNextEvent(currentTime);
                                nextEvents(1,find(nextEvents(2,:)==SEQGate.Inputs(indexInSEQ+1).Index)) = nextSEQEvent;
                            end
                        end
                    end
                else
                    if(strcmp(class(SEQGate.Inputs(indexInSEQ+1)),'BasicEvent'))
                        if(SEQGate.Inputs(indexInSEQ+1).FailureTime == Constants.INF && SEQGate.Inputs(indexInSEQ+1).RepairTime == Constants.INF)
                            nextSEQEvent = SEQGate.Inputs(indexInSEQ+1).SampleNextEvent(currentTime);
                            nextEvents(1,find(nextEvents(2,:)==SEQGate.Inputs(indexInSEQ+1).Index)) = nextSEQEvent;
                        end
                    end
                end
            end        
        end
    end
end 
