function nextEvents = generateFirstNextEventOccurrence (BEs)
    nextEvents = [];
    %% WITH SEQ GATE (REMOVE TO AVOID SEQ IMPLEMENTATION) %%
    for (i=1:length(BEs))
        isInputOfSEQ = false;
        %exclude hybrid BE to fail in Discrete Event Simulation
        %if(strcmp(BEs(i).FailureDistribution,'hybrid')==0)
            for(k=1:length(BEs(i).InputOf))
                isInputOfSEQ = false;
                SEQindexInBE = -1;
                if (strcmp(BEs(i).InputOf(k).Type,'SEQ'))
                    isInputOfSEQ = true;
                    SEQindexInBE = k;
                    break;
                end
            end
            if ((isInputOfSEQ && BEs(i).InputOf(SEQindexInBE).Inputs(1).Index ==BEs(i).Index) || ~isInputOfSEQ)
                nextEvents(1,i) = min(BEs(i).FailureTime, BEs(i).RepairTime);
                nextEvents(2,i) = BEs(i).Index;
            else
                BEs(i).FailureTime = Constants.INF;
                BEs(i).RepairTime = Constants.INF;
                nextEvents(1,i) = BEs(i).FailureTime;
                nextEvents(2,i) = BEs(i).Index;
            end
        %end
    end

    %% WITHOUT SEQ GATE (ADD TO AVOID SEQ IMPLEMENTATION) %%

    % for (i=1:length(BEs))
    %     nextEvents(1,i) = BEs(i).FailureTime;
    %     nextEvents(2,i) = BEs(i).Index;
    % end
    %%
end