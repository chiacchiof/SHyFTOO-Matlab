function postProcessVariable(deltaPoint, element, icolor)
    color = 'G';
    if nargin >= 2
        colorsplit = strsplit(icolor,'=');
        color = strrep(string(colorsplit(1)), ' ','');
    else
        disp('Not enough argument');
        return;
    end
        Tm = evalin('base','Tm');
        TimeStep = evalin('base','TimeStep');
        iter = evalin('base','counter_i')-1;
        %plot(1:deltaPoint:Tm,element(1:deltaPoint:Tm)/iter,color);
        scatter(1:deltaPoint:Tm,element(1:deltaPoint:Tm)/iter,color);
end