function nextEvents = evaluateFDEPGates (nextEvents, nextEvent, GATEs, currentTime)
    for i=1:length(GATEs)
        if(strcmp(GATEs(i).Type,'FDEP'))
            hasGateTriggered = false;
            primary = GATEs(i).Inputs(1);
            if(strcmp(class(primary),'Gate'))
                tempLastStatus = primary.Status;
                statusArray = primary.ComputeStatusInFDEP(currentTime);
                status = statusArray(1);
                if(tempLastStatus ~= primary.Status) %it means that the GATE has triggered
                    hasGateTriggered = true; 
                end
            %else it was a BE, it was evaluated in the triggering event routine
            else
                status = primary.Status;
            end
            %verify if the triggering event is a primary event of the FDEP
            if(~(isempty(find(nextEvent(2,:) == primary.Index))) || hasGateTriggered)
                %trigger the secondary input (according with the primary status)
                for (k=2:length(GATEs(i).Inputs))
                    %trigger is BAD, secondary are set to BAD
                    if (status == Constants.BAD)
                        GATEs(i).Inputs(k).SetStatus(Constants.BAD, currentTime)
                        GATEs(i).Inputs(k).InUseBy = Constants.MINUSONE;
                        if(strcmp(class(GATEs(i).Inputs(k)),'BasicEvent'))
                            nextEvents(1,find(nextEvents(2,:)==GATEs(i).Inputs(k).Index)) = Constants.INF;
                        end
                    %trigger is GOOD, secondary are not set to GOOD
                    %- BEs will recompute the repair time
                    %- Gates are not touched
                    else
                        if(strcmp(class(GATEs(i).Inputs(k)),'BasicEvent'))
                            %if the repair transition was not computed yet...it must be computed
                            if(GATEs(i).Inputs(k).RepairTime == Constants.INF)
                                nextEventInFDEP = GATEs(i).Inputs(k).SampleNextEvent(currentTime);
                                nextEvents(1,find(nextEvents(2,:)==GATEs(i).Inputs(k).Index)) = nextEventInFDEP;
                            %otherwise it is computed or used
                            else
                                if(GATEs(i).Inputs(k).RepairTime<currentTime)
                                    GATEs(i).Inputs(k).RepairTime = currentTime + Constants.TIMESTEP;
                                    nextEvents(1,find(nextEvents(2,:)==GATEs(i).Inputs(k).Index)) = GATEs(i).Inputs(k).RepairTime;
                                elseif  (GATEs(i).Inputs(k).RepairTime==currentTime)
                                    GATEs(i).Inputs(k).ComputeStatus(currentTime);
                                    nextEvents(1,find(nextEvents(2,:)==GATEs(i).Inputs(k).Index)) = GATEs(i).Inputs(k).SampleNextEvent(currentTime);
                                else
                                    nextEvents(1,find(nextEvents(2,:)==GATEs(i).Inputs(k).Index)) = GATEs(i).Inputs(k).RepairTime;
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end
