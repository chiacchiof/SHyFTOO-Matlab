function [value] = rround(inValue)
    value = inValue;
end

