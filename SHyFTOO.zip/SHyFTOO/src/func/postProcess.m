function postProcess(element, icolor)
    color = 'G';
    if nargin==1
        if(contains(strrep(element, ' ' , ''),'Color='))
            colorsplit = strsplit(element,'=');
            color = strrep(string(colorsplit(2)), ' ','');
            component = evalin('base','TOP');    
        else
            component = evalin('base',element);
        end
    elseif nargin == 2
        colorsplit = strsplit(icolor,'=');
        color = strrep(string(colorsplit(2)), ' ','');
        component = evalin('base',element);
    else
        component = evalin('base','TOP');    
    end
        Tm = evalin('base','Tm');
        TimeStep = evalin('base','TimeStep');
        DeltaPoint = TimeStep*100;
        iter = evalin('base','iter');
        bucket = [0:1:Tm];
        bucketHist = zeros(1,length(bucket));
        for (i=1:1:iter)
            tf_i = component.TimeOfFailureArray(i);
            if (tf_i<inf)
                ftap = round(component.TimeOfFailureArray(i));
                [m,i] = min(abs(bucket-ftap));
                bucketHist(i) = bucketHist(i) + 1;
            end
        end

        %plot([0:1:Tm],expcdf([0:1:Tm],1/lambda))
        %hold
        cdf = cumsum(bucketHist/iter);
        plot(1:DeltaPoint:Tm,cdf(1:DeltaPoint:Tm),color);
end