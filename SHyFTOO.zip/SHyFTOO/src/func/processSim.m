function y  = processSim(u)
    coder.extrinsic('evalin', 'assignin')
 
    %lambda = 0;
    %lambda =  evalin('base','lambda'); % Read value from workspace
    P_a = exp(-0.01); %reliability Lambda = 0.01, DT = 1
    y = 1;
    
    if (P_a < rand && u(1)<=u(2))
       assignin('base','t_fail',u(1)); % Assign value back to workspace
       y = 0;
       assignin('base','y',y); % Assign value back to workspace
    end
    
end