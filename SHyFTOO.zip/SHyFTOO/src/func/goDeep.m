function BE2Evaluate = goDeep (BE2Evaluate, BasicElement, level)
    TOP = evalin('base', 'TOP');
    FT = evalin('base', 'FT');
    for (j=1:length(BasicElement.InputOf))
        if(BasicElement.InputOf(j).Index == TOP.Index)
            BE2Evaluate(j,level) = BasicElement.InputOf(j).Index;
            break;
        end
        BE2Evaluate(j,level) = BasicElement.InputOf(j).Index;
        level = level+1;
        BE2Evaluate = goDeep(BE2Evaluate, BasicElement.InputOf(j), level);
    end 
end