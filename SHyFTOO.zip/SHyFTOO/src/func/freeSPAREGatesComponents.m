function [GATEs,nextEvents] = freeSPAREGatesComponents(GATEs, currentTime, nextEvents)    
    for(i=1:length(GATEs))
        %verify the cuncurrency among the spare gates of the Fault Tree
            if(strcmp(GATEs(i).Type,'SPARE'))
                statusInputs = GATEs(i).ArrayStatusInputs(currentTime);
                statusSpares = GATEs(i).ArrayStatusSpares(currentTime);
                nInputsFailed = sum(statusInputs(1,:)); %compute n. inputs failed in spare
                numOfSpareServed = GATEs(i).NumOfSpareServed(currentTime);        

        %free all spare components not necessary for the health of the spare gate

                %1. first of all remove the spare which are failed
                if(numOfSpareServed>0)
                    for(k=1:length(GATEs(i).Spares))
                        if(GATEs(i).Spares(k).InUseBy == GATEs(i).Index)
                            if (GATEs(i).Spares(k).Status == Constants.BAD)
                                GATEs(i).Spares(k).InUseBy = Constants.MINUSONE;
                                numOfSpareServed = numOfSpareServed - 1;
                            end
                        end
                    end
                end
                %2. counts the remaining one in use and still working
                numOfSpareServed = GATEs(i).NumOfSpareServed(currentTime);

                %3. remove the remaining one in use which are not needed
                j = 1;
                while(nInputsFailed<numOfSpareServed)
                    if(j<=length(GATEs(i).Spares))
                        if(GATEs(i).Spares(j).InUseBy == GATEs(i).Index)
                            GATEs(i).Spares(j).InUseBy = Constants.MINUSONE;
                            if(strcmp(class(GATEs(i).Spares(j)),'BasicEvent'))
                                nextSpareTimeToFailure = GATEs(i).Spares(j).SampleNextEvent(currentTime);
                                nextEvents(1,find(nextEvents(2,:)==GATEs(i).Spares(j).Index)) = nextSpareTimeToFailure;
                            end
                            numOfSpareServed = numOfSpareServed - 1; %decrement numOfSpareServed counter
                        end
                    else
                        break;
                    end
                    j = j+1;
                end
            end
    end
end