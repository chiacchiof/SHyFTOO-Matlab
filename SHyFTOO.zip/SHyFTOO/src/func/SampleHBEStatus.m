function y  = processSim(u)
    coder.extrinsic('evalin', 'assignin')
    HBEid = strcat(u(3:end-1))'; %to get the name of the Basic Event
    %lambda = 0;
    FTA =  evalin('base','FT'); % Read value from workspace
    indexComponent = 0;
    y = 1;
    for (i=1:length(FTA))
        if(strcmp(FTA(i).Name, HBEid))
            %retrieve the failure distribution of the component
            F = 1-exp(-u(end)); %unreliability Lambda = u(4), DT = 
            indexComponent = FTA(i).Index;
            break;
        end
    end
    indexBE = -1;
    
    if (F > rand && u(1)<=u(2))
        if (FTA(i).Status == Constants.GOOD)
            FTA(indexComponent).FailureTime = u(1);
        else
            FTA(indexComponent).RepairTime = u(1);
        end
       assignin('base','FT',FTA); % Assign value back to workspace
       assignin('base','currentTime',u(1)); % Assign value back to workspace
       assignin('base','indexTriggeringBE',indexComponent);
       y = 0; 
    end
    
end