function nextEvents = generateTestNextEventOccurrence (BEs)
    nextEvents = [];
    %% WITH SEQ GATE (REMOVE TO AVOID SEQ IMPLEMENTATION) %%
    for (i=1:length(BEs))
        isInputOfSEQ = false;
        %exclude hybrid BE to fail in Discrete Event Simulation
        %if(strcmp(BEs(i).FailureDistribution,'hybrid')==0)
            for(k=1:length(BEs(i).InputOf))
                isInputOfSEQ = false;
                SEQindexInBE = -1;
                if (strcmp(BEs(i).InputOf(k).Type,'SEQ'))
                    isInputOfSEQ = true;
                    SEQindexInBE = k;
                    break;
                end
            end
            nextEvents(1,i) = min(BEs(i).FailureTime, BEs(i).RepairTime);
            nextEvents(2,i) = BEs(i).Index;
        %end
    end

 end