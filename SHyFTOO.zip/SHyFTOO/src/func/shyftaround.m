function [value] = rround(inValue)
    value = round(inValue);
end

