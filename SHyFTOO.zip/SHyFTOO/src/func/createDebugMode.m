function debugLogFile = createDebugMode()
    fileName = strcat('LOG_',datestr(now,'ddmmyy_HHMMSS'),'.txt');
    myFolder = strcat(pwd,'\log');
    fullFileName = fullfile(myFolder, fileName);
%     fid = fopen(fullFileName, 'wt' );
%     fprintf(fid, ' FILE: %s \n', [fileName]);
%     fprintf(fid, ' ------- Simulation Settings  ---------- \n');
%     fprintf(fid, ' ------- Iter: %d \n', iter);
%     fprintf(fid, ' ------- TimeStep: %d \n', TimeStep);
%     debugFileId = fid;
    debugLogFile = log4m.getLogger(fullFileName);
    debugLogFile.setLogLevel(debugLogFile.ALL); 
end