function postProcess(deltaPoint, element, icolor)
    color = 'G';
    if nargin==2
        if(contains(strrep(element, ' ' , ''),'Color='))
            colorsplit = strsplit(element,'=');
            color = strrep(string(colorsplit(2)), ' ','');
            component = evalin('base','TOP');    
        else
            component = evalin('base',element);
        end
    elseif nargin == 3
        colorsplit = strsplit(icolor,'=');
        color = strrep(string(colorsplit(2)), ' ','');
        component = evalin('base',element);
    else
        component = evalin('base','TOP');    
    end
        Tm = evalin('base','Tm');
        TimeStep = evalin('base','TimeStep');
        iter = evalin('base','counter_i')-1;
        bucket = [0:1:Tm];
        bucketHist = zeros(1,length(bucket));
        for (i=1:1:iter)
            tf_i = component.TimeOfFailureArray(i);
            if (tf_i<inf)
                ftap = round(component.TimeOfFailureArray(i));
                [m,i] = min(abs(bucket-ftap));
                bucketHist(i) = bucketHist(i) + 1;
            end
        end

        %plot([0:1:Tm],expcdf([0:1:Tm],1/lambda))
        %hold
        cdf = cumsum(bucketHist/iter);
        %plot(1:deltaPoint:Tm,cdf(1:deltaPoint:Tm),color);
        scatter(1:deltaPoint:Tm,cdf(1:deltaPoint:Tm),color);
end