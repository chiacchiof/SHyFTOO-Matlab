currentTime = nextEventTime;

if debugMode
    debugLogFile.debug('',strcat('---------------------------------------------'));
    debugLogFile.debug('ZFTAevaluateFT',strcat('CurrentTime',mat2str(currentTime)));
    debugLogFile.debug('ZFTAevaluateFT',strcat('NextEvents',mat2str(nextEvents)));
end

tempStatusFT = zeros(2, length(FT));

for(i=1:length(FT))
    tempStatusFT(1, FT(i).Index) = FT(i).Status;
    tempStatusFT(2, FT(i).Index) = FT(i).LastStatusChange; 
end

%evaluate the triggering BASIC EVENT
triggeringBEs = []; 
for(i=1:simultaneousEvents)
    indexTriggeringBE = nextEvent(2,i);
    FT(indexTriggeringBE).ComputeStatus(currentTime);
    triggeringBEs = [triggeringBEs indexTriggeringBE];
end

%% BOTTOM UP Evaluation: it has been chosen to perform the TOP DOWN Evaluation
%bottomUPEvaluateFT

%% FDEP Evaluation
nextEvents = evaluateFDEPGates (nextEvents, nextEvent, FT_FDEPGates, currentTime);%evaluateFDEPGates (nextEvents, nextEvent, GATEs, currentTime);
%% SPARE Evaluation
[FT_SPAREGates, nextEvents] = freeSPAREGatesComponents (FT_SPAREGates, currentTime, nextEvents); %freeSPAREGatesComponents (GATEs, currentTime, nextEvents);

%% TOP DOWN Evaluation with recursive approach
TOP.ComputeStatus(currentTime);

%% sample next event for the BE
for(i=1:length(triggeringBEs))
    indexTriggeringBE = triggeringBEs(i);
    nextEvents(1,find(nextEvents(2,:)==indexTriggeringBE))= FT(indexTriggeringBE).SampleNextEvent(currentTime);
end

%% add in the nextEvents the next failure time of spare unit that has been allocated in a spare gate
for(i=1:length(FT_SPAREGates))
    tempSPARE = FT_SPAREGates(i);
    for(j=1:length(tempSPARE.Spares))
        secondaryInput = tempSPARE.Spares(j);
        if(secondaryInput.InUseBy~=Constants.MINUSONE && strcmp(class(secondaryInput),'BasicEvent'))
            nextEvents(1,find(nextEvents(2,:)==secondaryInput.Index)) = secondaryInput.FailureTime;
        end
    end 
end

%% SEQ EVALUATION
triggeringElements = []; %retrieve all the elements in the FT that have been triggered at currentTime
for(i=1:length(FT))
    if(FT(i).LastStatusChange == currentTime)
        triggeringElements = [triggeringElements FT(i).Index];
    end
end
triggeringSEQInputs = intersect(triggeringElements, allowedRepeatedSEQInputs);
nextEvents = evaluateSEQGates(triggeringSEQInputs, nextEvents, FT, tempStatusFT, currentTime);

%% UPDATE Availability UpTime
triggeringElements = []; %AFTER SEQ EVALUATION, retrieve all the elements that have been triggered 
for(i=1:length(FT))
    if(FT(i).LastStatusChange == currentTime)
        triggeringElements = [triggeringElements FT(i).Index];
    end
end

%% set and reset important status information for triggered elements
for(i=1:length(triggeringElements))
    indexComponent = triggeringElements(i);
    lastButOneStatus = tempStatusFT(1, FT(indexComponent).Index);
    lastButOneStatusChange = tempStatusFT(2, FT(indexComponent).Index);
    FT(indexComponent).UpdateUpTime(lastButOneStatus, lastButOneStatusChange, FT(indexComponent).LastStatusChange, currentTime);
    if debugMode
        debugLogFile.debug('ZFTAmain',strcat('Triggered: ',FT(indexComponent).Name,'-- Status -- ', mat2str(FT(indexComponent).Status)));
    end
end
%%

computeNextEvents;
