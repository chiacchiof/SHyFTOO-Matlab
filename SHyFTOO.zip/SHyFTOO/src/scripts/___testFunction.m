for(i=1:length(obj.Inputs))
                value = [value obj.Inputs(i).Status];
end