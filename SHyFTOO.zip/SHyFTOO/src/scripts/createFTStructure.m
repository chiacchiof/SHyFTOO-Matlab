
%% Assign Index to BE %%
counterComponents = 1; %counter to sort components in the FT Heterogeneous Array
components = whos;

counterBE = 1;
for i=1:length(components)
    if(strcmp(components(i).class,'BasicEvent'))
        temp = eval(components(i).name);
        temp.Index = counterComponents;
        FT(counterComponents) = temp;
        BEs(counterBE) = temp;
        clear temp;
        counterComponents = counterComponents + 1;
        counterBE = counterBE + 1;
    end
end

%% Assign Index to Gate%%
components = whos;

counterGATES = 1;
for i=1:length(components)
    if(strcmp(components(i).class,'Gate'))
        if(strcmp(components(i).name,'TOP')==0)
            temp = eval(components(i).name);
            temp.Index = counterComponents;
            FT(counterComponents) = temp;
            GATEs(counterGATES) = temp;
            clear temp;
            counterComponents = counterComponents + 1;
            counterGATES = counterGATES + 1;
        end
    end
end

%% Complete GATE structure support array and BEs definition %%

FT_FDEPGates = [];
FT_SEQGates = [];
FT_SPAREGates = [];

allowedRepeatedSEQInputs = []; %this vector is filled into "validateFTStructure.m". It contains the index of the input of SEQ gates

for i=1:length(GATEs)
    %fill the structure of the FDEP and SEQ Gates (to shorten simulations)
    if(strcmp(GATEs(i).Type,Constants.FDEP))
        FT_FDEPGates = [FT_FDEPGates GATEs(i)];
    elseif (strcmp(GATEs(i).Type,Constants.SEQ))
        FT_SEQGates = [FT_SEQGates GATEs(i)];
    elseif (strcmp(GATEs(i).Type,Constants.SPARE))
        FT_SPAREGates = [FT_SPAREGates GATEs(i)];
    end
    
    %complete the definition of the GATES (indexing the InputOf)
    %Not allowed 0-input Gates
    if (~GATEs(i).IsEmptyInputs())
        for (j=1:length(GATEs(i).Inputs))
            GATEs(i).Inputs(j).InputOf = [GATEs(i).Inputs(j).InputOf, GATEs(i)];
        end
    else
        %Not allowed 0-input Gates
        fprintf('Not allowed 0-input gate %s \n',GATEs(i).Name);
        UNVALID_FT = 1;
        return;
    end
    
    if (~GATEs(i).IsEmptySpares())
        for (j=1:length(GATEs(i).Spares))
            GATEs(i).Spares(j).SpareOf = [GATEs(i).Spares(j).SpareOf, GATEs(i)];
        end
    end
end

%% Validate FT Structure %%
% Not allowed repeated BEs: 
%0. SEQ inputs not allowed in multiple SEQ Gates.
%1. SEQ inputs cannot feed other gates
%2. SPARE secondary inputs are allowed only among SPARE gates

validateFTStructure;

%% First Generation of Events 
nextEvents = generateFirstNextEventOccurrence (BEs);

computeNextEvents;