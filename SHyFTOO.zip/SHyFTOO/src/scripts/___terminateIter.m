
set_param(bdroot,'SimulationCommand', 'WriteDataLogs');
set_param(bdroot,'SimulationCommand','Stop');
if(counter_i<iter)
    counter_i = counter_i+1
    if lab == 1
        rng('shuffle');       
        lab = 2;
        bdroot = 'test_exp_2';
        disp('Failure - > cambiamento di lab da 1 a 2 --->: ');
    else
        lab = 1;
        bdroot = 'test_exp_1';
        disp('Failure - > cambiamento di lab da 2 a 1 --->');
    end
    
    failureTime(counter_i) = t_fail;
    t_fail = 1000000;
    y = 1;

    set_param(bdroot,'SimulationCommand','Update');
    set_param(bdroot,'SimulationCommand','Start');
end
%sum(failureTime(:) == -1)/counter_i