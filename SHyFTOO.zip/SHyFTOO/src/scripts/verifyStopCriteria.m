% if(TOP.NFailure>0)
%     xval = TOP.NFailure/counter_i; %% simulated reliability
%     delta_i = xval - mu_i;
%     mu_i = mu_i + delta_i/counter_error;
%     S_i = S_i + (delta_i^2)*(counter_error-1)/counter_error;
%     if counter_error>1
%         varX = S_i/(counter_error - 1);
%         accepted_error = mu_i*percentageErrorTollerance ;
%         err = (zvalue*1.2*varX^0.5)/counter_error^0.5;
%         err_vect = [err_vect err];
%         if err<=accepted_error
%             stopCriteriaMet=true;
%         end
%     end
%     counter_error = counter_error +1;
% end

if(TOP.NFailure>10)
    xval = TOP.NFailure/counter_i; %% simulated reliability
    delta_i = xval - mu_i;
    mu_i = mu_i + delta_i/(counter_i+1);
    S_i = S_i + (delta_i^2)*(counter_i)/(counter_i+1);
    if counter_i>1
        varX = S_i/(counter_i);
        accepted_error = mu_i*percentageErrorTollerance ;
        err = (zvalue*1.2*varX^0.5)/counter_i^0.5;
        err_vect = [err_vect err];
        if err<=accepted_error
            stopCriteriaMet=true;
        end
    end
end