for i=1:length(BEs)
    %update UpTime of the gate (call method from superclass)
    BEs(i).ComputeUpTime(Tm);
end

for i=1:length(GATEs)
    GATEs(i).ComputeUpTime(Tm);
end