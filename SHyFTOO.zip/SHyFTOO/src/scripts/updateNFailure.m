for i=1:length(BEs)
    BEs(i).UpdateNFailure(Tm);
end

for i=1:length(GATEs)
    GATEs(i).UpdateNFailure(Tm);
end