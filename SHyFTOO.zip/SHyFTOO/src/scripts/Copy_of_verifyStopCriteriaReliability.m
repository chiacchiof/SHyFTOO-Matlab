if(TOP.NFailure>0)
    xval = TOP.NFailure/counter_i; %% simulated reliability
    TOP_i = [TOP_i xval];
    counter_error = length(TOP_i);
    muX = sum(TOP_i(1,1:counter_error))/counter_error;
    accepted_error = muX*percentageErrorTollerance ;
    err_i = [err_i (xval - muX)^2];
    varX = (1/(counter_error-1))*sum(err_i(1,1:counter_error));
    err = (zvalue*1.2*varX^0.5)/counter_error^0.5;
    err_vect = [err_vect err];
    if err<=accepted_error
        stopCriteriaMet=true;
    end
end