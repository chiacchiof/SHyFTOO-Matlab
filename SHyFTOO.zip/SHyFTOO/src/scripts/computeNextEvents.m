
nextEvents = sortrows(rround(nextEvents'),1)';
onlyInfinitive = nnz(nextEvents(1,:)==inf);
if(onlyInfinitive==length(nextEvents(1,:)))
    simultaneousEvents = 1;
else
    eventsIndex = nextEvents(2,find(nextEvents(1,:)==min(nextEvents(1,:))));
    simultaneousEvents = length(eventsIndex);
end
nextEvent = nextEvents(:,1:simultaneousEvents);
nextEventTime = nextEvent(1);