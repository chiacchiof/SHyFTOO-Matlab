%%CASE 0:  SEQ input (Gates or BE) must be uniques

allowedRepeatedSEQInputs = [];
for i=1:length(GATEs)
    if(strcmp(GATEs(i).Type, Constants.SEQ))
        for k=1:length(GATEs(i).Inputs)
            if(~ismember(GATEs(i).Inputs(k).Index, allowedRepeatedSEQInputs))
                allowedRepeatedSEQInputs = [allowedRepeatedSEQInputs, GATEs(i).Inputs(k).Index];
            else
                fprintf('Not allowed repeated input %s in SEQ gate %s \n',FT(GATEs(i).Inputs(k).Index).Name, GATEs(i).Name);
                UNVALID_FT = 1;
                clear allowedRepeatedSEQInputs;
                return;
            end
        end
    end
end

%not allow input of a SEQ in other gates
for i=1:length(GATEs)
    if(~strcmp(GATEs(i).Type, Constants.SEQ))
        for k=1:length(GATEs(i).Inputs)
            if(ismember(GATEs(i).Inputs(k).Index, allowedRepeatedSEQInputs))
                fprintf('Not allowed input %s in gate %s because repeated in a SEQ Gate \n',FT(GATEs(i).Inputs(k).Index).Name, GATEs(i).Name);
                fprintf('Consider to use the output of the SEQ Gate having that input as input of the gate %s \n', GATEs(i).Name);
                UNVALID_FT = 1;
                clear allowedRepeatedSEQInputs;
                return;
            end
        end
    end
end

%% CASE 1: SPARE secondary inputs (BE only) are allowed only among SPARE gates
allowedRepeatedSPARESInputs = [];
for i=1:length(GATEs)
    if(strcmp(GATEs(i).Type, Constants.SPARE))
        for k=1:length(GATEs(i).Spares)
            if(strcmp(class(GATEs(i).Spares(k)),'BasicEvent'))
                allowedRepeatedSPARESInputs = [allowedRepeatedSPARESInputs, GATEs(i).Spares(k).Index];
            end
        end
    end
end
spareInputs = unique(allowedRepeatedSPARESInputs);
for i=1:length(GATEs)
    for k=1:length(GATEs(i).Inputs)
        if(ismember(GATEs(i).Inputs(k).Index, spareInputs))
            fprintf('Not allowed input %s in gate %s because being spares of a SPARE Gate \n',FT(GATEs(i).Inputs(k).Index).Name, GATEs(i).Name);
            UNVALID_FT = 1;
            clear allowedRepeatedSPARESInputs;
            return;
        end
    end
end


