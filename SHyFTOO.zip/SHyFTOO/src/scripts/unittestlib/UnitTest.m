function [currentTime, nextEvents, nextEvent, nextEventTime] = UnitTest (testDesign)
    BEs = evalin('base', 'BEs');
    GATEs = evalin('base', 'GATEs');
    
    nextEventTime = 0;
    nextEvents = [];
    nextEvent = Inf;
    currentTime = Inf;
    for (i=1:length(BEs))
        BEs(i).FailureTime = Inf;
        BEs(i).RepairTime = Inf;
    end
    
    feval(testDesign);
    %TestDesign();
    
    %% this section does not be modified
    if nextEventTime < Inf
        nextEvents = generateTestNextEventOccurrence (BEs);
        nextEvents = sortrows(rround(nextEvents'),1)';
        onlyInfinitive = nnz(nextEvents(1,:)==inf);
        if(onlyInfinitive==length(nextEvents(1,:)))
            simultaneousEvents = 1;
        else
            eventsIndex = nextEvents(2,find(nextEvents(1,:)==min(nextEvents(1,:))));
            simultaneousEvents = length(eventsIndex);
        end
        nextEvent = nextEvents(:,1:simultaneousEvents);
        nextEventTime = nextEvent(1);
    end
end