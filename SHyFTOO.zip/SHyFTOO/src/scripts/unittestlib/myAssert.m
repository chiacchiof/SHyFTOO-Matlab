function [] = myAssert(nameComponent, attribute, expectedValue, nextEventTimeTest) 
    FT = evalin('base', 'FT');
    elementInFT = 0;
    for(i=1:length(FT))
        if (strcmp(FT(i).Name, nameComponent))
            elementInFT = strcat('FT(',string(FT(i).Index),')');
            break;
        end
    end
    value = eval (strcat(elementInFT,'.',attribute));  
    
    expectedInFT = expectedValue;
    expectedValue = strsplit(expectedValue,'.'); %pay attention when comparing with float numbers
    if (length(expectedValue)>1 && (~strcmp(expectedValue(1),'Constants')))
        for(i=1:length(FT))
            if (strcmp(FT(i).Name, expectedValue(1)))
                expectedInFT = strcat('FT(',string(FT(i).Index),')','.',expectedValue(2));
                break;
            end
        end
    end
    
    if (value ~= eval(expectedInFT))
        dbstack();
        X = sprintf ('error %s time %d \n', eval (strcat(elementInFT,'.Name')), nextEventTimeTest);
        fprintf (2, X);
    end
end