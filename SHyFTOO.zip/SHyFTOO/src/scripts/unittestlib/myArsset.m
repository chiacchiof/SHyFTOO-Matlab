function [] = myAssert(nameComponent, attribute, settingValue) 
    FT = evalin('base', 'FT');
    elementInFT = 0;
    for(i=1:length(FT))
        if (strcmp(FT(i).Name, nameComponent))
            elementInFT = strcat('FT(',string(FT(i).Index),')');
            break;
        end
    end
    eval (strcat(elementInFT,'.',attribute,'=',string(settingValue),';'));
end