
%update SHyFTA performance metrics
shyftaVariables = shyftaVariables+simout.Data;

t2fill = [0:Tm];

observed_times = lambda_HBE1.Time';
observed_data = lambda_HBE1.Data';
[~,ind] = ismember(t2fill,observed_times);
impute_data = [0, observed_data];
ind = ind +1 ;
corr_data = impute_data(ind)';
lambda_hbe1_cum = lambda_hbe1_cum+corr_data;

observed_times = lambda_HBE2.Time';
observed_data = lambda_HBE2.Data';
[~,ind] = ismember(t2fill,observed_times);
impute_data = [0, observed_data];
ind = ind +1 ;
corr_data = impute_data(ind)';
lambda_hbe2_cum = lambda_hbe2_cum+corr_data;

%update PH SHyFTA performance metrics
%shyftaVariables = shyftaVariables+VI;