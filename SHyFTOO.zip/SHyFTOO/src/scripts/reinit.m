for i=1:length(BEs)
    BEs(i).ClearIterationProperty();
end

for i=1:length(GATEs)
    GATEs(i).ClearIterationProperty();
end

%% NextEvent
nextEvents = generateFirstNextEventOccurrence (BEs);

computeNextEvents;