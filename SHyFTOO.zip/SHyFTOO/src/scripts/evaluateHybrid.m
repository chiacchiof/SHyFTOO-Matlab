hasHybridTriggered = 0;
for (i=1:length(BEs))
    if(BEs(i).Status==Constants.GOOD && strcmp(BEs(i).FailureDistribution,'hybrid'))
        F = 1-exp(-BEs(i).FailureArgs(1)); 
        indexComponent = BEs(i).Index;
        if (F > rand)
           FT(indexComponent).FailureTime = currentTime;
           indexTriggeringBE=indexComponent;
           hasHybridTriggered = 1;
           break;
        end
    end
end