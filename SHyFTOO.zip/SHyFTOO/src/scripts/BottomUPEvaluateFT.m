
%% enqueue the Basic Elements to be evaluated in a levelled matrix
MatrixBE2Evaluate = [];
level = 1;
for(i=1:length(triggeringBEs))
    BE2Evaluate = [];
    BasicElement = FT(triggeringBEs(i));
    BE2Evaluate = goDeep(BE2Evaluate, BasicElement, level);
    length_BE2Evaluate = length(BE2Evaluate);
    
    row = size(MatrixBE2Evaluate, 1);
    col = size(MatrixBE2Evaluate, 2);
    if(length_BE2Evaluate>col)
        MatrixBE2Evaluate = [zeros(row, length_BE2Evaluate-col) MatrixBE2Evaluate; BE2Evaluate];
    elseif (length_BE2Evaluate<col)
        MatrixBE2Evaluate = [MatrixBE2Evaluate; zeros(1, col-length_BE2Evaluate) BE2Evaluate];
    else
        MatrixBE2Evaluate = [MatrixBE2Evaluate; BE2Evaluate];
    end
end
MatrixBE2Evaluate;
%% Evaluate the enqueued Basic Elements
for(i=1:size(MatrixBE2Evaluate,2)) %check each column of the matrix from left to right
    layerToEvaluate = nonzeros(unique(MatrixBE2Evaluate(:,i)));
    for (j=1:length(layerToEvaluate))
        %the ComputeStatus should be modified
        FT(layerToEvaluate(j)).ComputeStatus(currentTime);
    end
end
