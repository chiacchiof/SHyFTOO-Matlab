outputFullFileStopCriteria = fullfile(pwd, '\src\scripts\verifyStopCriteria.m');
if(TOP.IsFailureGate)
    inputFullFileStopCriteria = fullfile(pwd, '\src\scripts\verifyStopCriteriaReliability.m');
else
    inputFullFileStopCriteria = fullfile(pwd, '\src\scripts\verifyStopCriteriaAvailability.m');
end
copyfile (inputFullFileStopCriteria, outputFullFileStopCriteria);
clear inputFullFileStopCriteria outputFullFileStopCriteria;