if (hasHybridTriggered)
    nextEvents(1,find(nextEvents(2,:)==indexTriggeringBE)) = FT(indexTriggeringBE).FailureTime;
    nextEvents = sortrows(rround(nextEvents'),1)';
    nextEvent = nextEvents(:,1);
    nextEventTime = nextEvent(1);
    simultaneousEvents = 1;
end
if(currentTime == nextEvents(1,1))
    if debugMode
        debugLogFile.debug('',strcat('---------------------------------------------'));
        debugLogFile.debug('PHevaluateFT',strcat('CurrentTime',mat2str(currentTime)));
        debugLogFile.debug('PHevaluateFT',strcat('NextEvents',mat2str(nextEvents)));
    end

    tempStatusFT = zeros(2, length(FT));

    for(i=1:length(FT))
        tempStatusFT(1, FT(i).Index) = FT(i).Status;
        tempStatusFT(2, FT(i).Index) = FT(i).LastStatusChange; 
    end

    %evaluate the triggering BASIC EVENT
    triggeringBEs = []; 
    for(i=1:simultaneousEvents)
        indexTriggeringBE = nextEvent(2,i);
        FT(indexTriggeringBE).ComputeStatus(currentTime);
        triggeringBEs = [triggeringBEs indexTriggeringBE];
    end
    
    %% FDEP Evaluation
    nextEvents = evaluateFDEPGates (nextEvents, nextEvent, FT_FDEPGates, currentTime);%evaluateFDEPGates (nextEvents, nextEvent, GATEs, currentTime);
    %% SPARE Evaluation
    [FT_SPAREGates, nextEvents] = freeSPAREGatesComponents (FT_SPAREGates, currentTime, nextEvents); %freeSPAREGatesComponents (GATEs, currentTime, nextEvents);
    %% TOP EVENT Evaluation
    TOP.ComputeStatus(currentTime);
    %% sample next event for the BE
    %nextEvent is updated with the next repair time of the failed HBE
    nextEvents(1,find(nextEvents(2,:)==indexTriggeringBE))= FT(indexTriggeringBE).SampleNextEvent(currentTime);


    %% handle failuretime of spare event that has been allocated in a spare gate
    for(i=1:length(FT_SPAREGates))
        tempSPARE = FT_SPAREGates(i);
        for(j=1:length(tempSPARE.Spares))
            secondaryInput = tempSPARE.Spares(j);
            if(secondaryInput.InUseBy~=Constants.MINUSONE && strcmp(class(secondaryInput),'BasicEvent'))
                nextEvents(1,find(nextEvents(2,:)==secondaryInput.Index)) = secondaryInput.FailureTime;
            end
        end 
    end


    %% SEQ EVALUATION %%
    triggeringElements = []; %retrieve all the elements that have been triggered
    for(i=1:length(FT))
        if(FT(i).LastStatusChange == currentTime)
            triggeringElements = [triggeringElements FT(i).Index];
        end
    end

    nextEvents = evaluateSEQGates(triggeringElements, nextEvents, FT, currentTime);

    %% UPDATE Availability UpTime (this function was removed in class BasicEvent (line 92) and Gate (line 224-232) ) %%
    triggeringElements = []; %retrieve all the elements that have been triggered
    for(i=1:length(FT))
        if(FT(i).LastStatusChange == currentTime)
            triggeringElements = [triggeringElements FT(i).Index];
        end
    end

    %% set and reset important status information for triggered elements
    for(i=1:length(triggeringElements))
        indexComponent = triggeringElements(i);
        lastButOneStatus = tempStatusFT(1, FT(indexComponent).Index);
        lastButOneStatusChange = tempStatusFT(2, FT(indexComponent).Index);
        FT(indexComponent).UpdateUpTime(lastButOneStatus, lastButOneStatusChange, FT(indexComponent).LastStatusChange, currentTime); 
        if debugMode
            debugLogFile.debug('SHyFTAmain',strcat('Triggered: ',FT(indexComponent).Name,'-- Status -- ', mat2str(FT(indexComponent).Status)));
        end
    end
    %%
    computeNextEvents;   
end