clear all; %to modify to clear only PROGRAMS variables
addpath(genpath(pwd));
tic
UNVALID_FT = 0; % 0, FT is valid (1 otherwise) This check is performed inside the "initFaultTree" script.

inputFullFileNameRound = fullfile(pwd, '\src\func\zround.m');
outputFullFileNameRound = fullfile(pwd, '\src\func\rround.m');
copyfile (inputFullFileNameRound, outputFullFileNameRound);
clear inputFullFileNameRound outputFullFileNameRound;

%% SIMULATION PARAMETERS
debugMode = false;
iter = 10000000;
stopCriteriaOn = false;
%% STOP CRITERIA PARAMETERS
confidenceLevel = 0.95;
percentageErrorTollerance = 0.001;
zvalue = norminv(1-((1-confidenceLevel)/2));
err_iter = 0;
muX =  0;
err_i = 0;
err_vect = 0;
TOP_i = 0;
stopCriteriaMet = false;

counter_error = 1;
mu_i = 0;
S_i = 0;
%%
rng('shuffle')
failureTime = zeros(1,iter);

TimeStep = Constants.TIMESTEP;
currentTime = 0;
counter_i = 1;

%% Debug Mode
if debugMode
   debugLogFile = createDebugMode; %return the ID to the debug file
end
%%

initFaultTree_AFW_C4_64_DFT_ccf
%initFaultTree
if (UNVALID_FT)
    return
end

setStopCriteria;

ttfComponents = zeros(counterComponents-1,iter);
while(nextEventTime<Tm) 
    ZFTAevaluateFT;
end
computeUpTime;
updateNFailure;

for counter_i=2:iter
    if(~stopCriteriaMet)
        reinit;
        while(nextEventTime<Tm) 
            ZFTAevaluateFT;
        end
        computeUpTime;
        updateNFailure;
        if(stopCriteriaOn)
            verifyStopCriteria; 
        end
       % disp(counter_i);
    else
        toc
        return;
    end
    if(mod(counter_i,100000)==0)
        save('workspace_great');
    end
end
toc

